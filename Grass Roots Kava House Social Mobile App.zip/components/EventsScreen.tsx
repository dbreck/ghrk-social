import { useState, useEffect, useRef } from 'react';
import { Calendar, Clock, MapPin, Users, Plus, Star, Sparkles, X, Upload, Loader2, Image as ImageIcon, ChevronRight, Edit3, Trash2, MoreHorizontal } from 'lucide-react';
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "./ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";
import { ImageWithFallback } from './figma/ImageWithFallback';
import { projectId, publicAnonKey } from "../utils/supabase/info";

interface Event {
  id: string;
  title: string;
  description: string;
  event_date: string;
  event_time: string;
  location: string;
  max_attendees: number;
  category: string;
  cover_image?: string;
  host_id: string;
  host_name: string;
  attendees: string[];
  interested: string[];
  attending_count: number;
  interested_count: number;
  created_at: string;
  updated_at: string;
}

interface EventsScreenProps {
  accessToken: string;
}

export function EventsScreen({ accessToken }: EventsScreenProps) {
  const [events, setEvents] = useState<Event[]>([]);
  const [myEvents, setMyEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("upcoming");
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [showEditEvent, setShowEditEvent] = useState(false);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Create/Edit event form state
  const [eventForm, setEventForm] = useState({
    title: "",
    description: "",
    event_date: "",
    event_time: "",
    location: "",
    max_attendees: 50,
    category: "social",
    cover_image: ""
  });
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>("");
  const [imageBase64, setImageBase64] = useState<string>("");
  const [submittingEvent, setSubmittingEvent] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Delete confirmation state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [eventToDelete, setEventToDelete] = useState<string | null>(null);
  const [deletingEventId, setDeletingEventId] = useState<string | null>(null);

  // User RSVP tracking
  const [userRSVPs, setUserRSVPs] = useState<{[eventId: string]: string}>({});

  useEffect(() => {
    loadEvents();
    loadMyEvents();
    // Set up polling for updates
    const interval = setInterval(() => {
      loadEvents();
      loadMyEvents();
    }, 30000); // Poll every 30 seconds
    return () => clearInterval(interval);
  }, [accessToken]);

  const loadEvents = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events?limit=50`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to load events');
        return;
      }

      setEvents(data.events);
      
      // Track user RSVP status for each event
      const rsvpStatus: {[eventId: string]: string} = {};
      const currentUserId = getCurrentUserId();
      
      data.events.forEach((event: Event) => {
        if (event.attendees?.includes(currentUserId)) {
          rsvpStatus[event.id] = 'going';
        } else if (event.interested?.includes(currentUserId)) {
          rsvpStatus[event.id] = 'interested';
        } else {
          rsvpStatus[event.id] = 'not_going';
        }
      });
      
      setUserRSVPs(rsvpStatus);
    } catch (err) {
      setError('Failed to load events');
      console.error('Load events error:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadMyEvents = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events/my-events`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Failed to load my events:', data.error);
        return;
      }

      setMyEvents(data.events);
    } catch (err) {
      console.error('Load my events error:', err);
    }
  };

  const getCurrentUserId = () => {
    try {
      const payload = JSON.parse(atob(accessToken.split('.')[1]));
      return payload.sub || "current-user";
    } catch {
      return "current-user";
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleCreateEvent = async () => {
    if (!eventForm.title.trim() || !eventForm.description.trim() || submittingEvent) return;

    setSubmittingEvent(true);
    setError("");

    try {
      let coverImage = null;
      
      // Use base64 encoded image for persistence
      if (selectedImage && imageBase64) {
        coverImage = imageBase64;
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          ...eventForm,
          cover_image: coverImage,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to create event');
        return;
      }

      // Reset form and close modal
      resetForm();
      setShowCreateEvent(false);
      setSuccess("Event created successfully!");
      
      // Reload events
      await loadEvents();
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError('Failed to create event');
      console.error('Create event error:', err);
    } finally {
      setSubmittingEvent(false);
    }
  };

  const handleEditEvent = async () => {
    if (!eventForm.title.trim() || !eventForm.description.trim() || submittingEvent || !editingEvent) return;

    setSubmittingEvent(true);
    setError("");

    try {
      let coverImage = eventForm.cover_image;
      
      // Use base64 encoded image for persistence if new image selected
      if (selectedImage && imageBase64) {
        coverImage = imageBase64;
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events/${editingEvent.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          ...eventForm,
          cover_image: coverImage,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to update event');
        return;
      }

      // Reset form and close modal
      resetForm();
      setShowEditEvent(false);
      setEditingEvent(null);
      setSuccess("Event updated successfully!");
      
      // Reload events
      await loadEvents();
      await loadMyEvents();
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError('Failed to update event');
      console.error('Update event error:', err);
    } finally {
      setSubmittingEvent(false);
    }
  };

  const handleDeleteEvent = async (eventId: string) => {
    setDeletingEventId(eventId);
    setError("");

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events/${eventId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to delete event');
        return;
      }

      // Remove event from local state
      setEvents(events.filter(event => event.id !== eventId));
      setMyEvents(myEvents.filter(event => event.id !== eventId));
      setSuccess("Event deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError('Failed to delete event');
      console.error('Delete event error:', err);
    } finally {
      setDeletingEventId(null);
      setShowDeleteConfirm(false);
      setEventToDelete(null);
    }
  };

  const openEditEvent = (event: Event) => {
    setEditingEvent(event);
    setEventForm({
      title: event.title,
      description: event.description,
      event_date: event.event_date,
      event_time: event.event_time,
      location: event.location,
      max_attendees: event.max_attendees,
      category: event.category,
      cover_image: event.cover_image || ""
    });
    
    // If there's an existing image, set the preview
    if (event.cover_image) {
      setImagePreview(event.cover_image);
      setImageBase64(event.cover_image);
    }
    
    setShowEditEvent(true);
  };

  const confirmDeleteEvent = (eventId: string) => {
    setEventToDelete(eventId);
    setShowDeleteConfirm(true);
  };

  const resetForm = () => {
    setEventForm({
      title: "",
      description: "",
      event_date: "",
      event_time: "",
      location: "",
      max_attendees: 50,
      category: "social",
      cover_image: ""
    });
    setSelectedImage(null);
    setImagePreview("");
    setImageBase64("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleRSVP = async (eventId: string, status: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/events/${eventId}/rsvp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ status }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to update RSVP');
        return;
      }

      // Update local state
      setUserRSVPs(prev => ({
        ...prev,
        [eventId]: status
      }));

      // Update events list with new counts
      setEvents(events.map(event => 
        event.id === eventId 
          ? { 
              ...event, 
              attending_count: data.event.attending_count,
              interested_count: data.event.interested_count,
              attendees: data.event.attendees,
              interested: data.event.interested
            }
          : event
      ));

      // Reload my events if status changed to/from going
      if (status === 'going' || userRSVPs[eventId] === 'going') {
        await loadMyEvents();
      }
    } catch (err) {
      setError('Failed to update RSVP');
      console.error('RSVP error:', err);
    }
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (5MB limit for base64 storage)
    if (file.size > 5 * 1024 * 1024) {
      setError('File too large. Maximum size is 5MB.');
      return;
    }

    // Check file type
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file.');
      return;
    }

    setSelectedImage(file);
    
    try {
      // Create preview URL
      const previewUrl = URL.createObjectURL(file);
      setImagePreview(previewUrl);

      // Convert to base64 for persistent storage
      const base64 = await convertFileToBase64(file);
      setImageBase64(base64);
      
      setError("");
    } catch (err) {
      setError('Failed to process file');
      console.error('File processing error:', err);
    }
  };

  const removeImage = () => {
    if (imagePreview && !imagePreview.startsWith('data:')) {
      URL.revokeObjectURL(imagePreview);
    }
    setSelectedImage(null);
    setImagePreview("");
    setImageBase64("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(':');
    const date = new Date();
    date.setHours(parseInt(hours), parseInt(minutes));
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'ceremony': return 'bg-gradient-to-r from-purple-500/20 to-indigo-500/20 text-purple-300 border-purple-500/30';
      case 'education': return 'bg-gradient-to-r from-blue-500/20 to-cyan-500/20 text-blue-300 border-blue-500/30';
      case 'social': return 'bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-300 border-green-500/30';
      case 'community': return 'bg-gradient-to-r from-orange-500/20 to-yellow-500/20 text-orange-300 border-orange-500/30';
      default: return 'bg-slate-700/50 text-slate-300 border-slate-600/30';
    }
  };

  // Get minimum date (today) for date input
  const getMinDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  const isEventOwner = (event: Event) => {
    return event.host_id === getCurrentUserId();
  };

  if (loading) {
    return (
      <div className="h-full bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-slate-400 mx-auto mb-4 animate-spin" />
          <p className="text-slate-400">Loading events...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-900">
      {/* Header with gradient */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-4 border-b border-slate-600 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500 opacity-5 rounded-full translate-x-16 -translate-y-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-500 opacity-5 rounded-full -translate-x-12 translate-y-12"></div>
        
        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center">
              <Calendar className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-lg font-medium text-white">Events</h2>
          </div>
          <Button 
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg shadow-blue-500/20"
            onClick={() => {
              resetForm();
              setShowCreateEvent(true);
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Event
          </Button>
        </div>
      </div>

      {/* Success/Error Messages */}
      {error && (
        <Alert className="m-4 bg-red-900/20 border-red-800 text-red-200">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="m-4 bg-green-900/20 border-green-800 text-green-200">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {/* Create Event Modal */}
      <Dialog open={showCreateEvent} onOpenChange={setShowCreateEvent}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-center text-white">Create Event</DialogTitle>
            <DialogDescription className="text-center text-slate-400">
              Share your event with the Grass Roots community
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Event Title</Label>
              <Input
                placeholder="What's your event called?"
                value={eventForm.title}
                onChange={(e) => setEventForm({...eventForm, title: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">Description</Label>
              <Textarea
                placeholder="Tell people more about your event..."
                value={eventForm.description}
                onChange={(e) => setEventForm({...eventForm, description: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 resize-none min-h-[100px] focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-slate-300">Date</Label>
                <Input
                  type="date"
                  value={eventForm.event_date}
                  min={getMinDate()}
                  onChange={(e) => setEventForm({...eventForm, event_date: e.target.value})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Time</Label>
                <Input
                  type="time"
                  value={eventForm.event_time}
                  onChange={(e) => setEventForm({...eventForm, event_time: e.target.value})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">Location</Label>
              <Input
                placeholder="Where is your event?"
                value={eventForm.location}
                onChange={(e) => setEventForm({...eventForm, location: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-slate-300">Max Attendees</Label>
                <Input
                  type="number"
                  min="1"
                  max="1000"
                  value={eventForm.max_attendees}
                  onChange={(e) => setEventForm({...eventForm, max_attendees: parseInt(e.target.value) || 50})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Category</Label>
                <Select 
                  value={eventForm.category} 
                  onValueChange={(value) => setEventForm({...eventForm, category: value})}
                  disabled={submittingEvent}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="social">Social</SelectItem>
                    <SelectItem value="ceremony">Ceremony</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="community">Community</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {imagePreview && (
              <div className="relative">
                <div className="rounded-lg overflow-hidden border border-slate-600">
                  <img 
                    src={imagePreview} 
                    alt="Event cover" 
                    className="w-full h-32 object-cover"
                  />
                </div>
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute top-2 right-2 w-8 h-8 p-0 rounded-full"
                  onClick={removeImage}
                  disabled={submittingEvent}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                  disabled={submittingEvent}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={submittingEvent}
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Add Cover
                </Button>
              </div>
              
              <Button
                onClick={handleCreateEvent}
                disabled={!eventForm.title.trim() || !eventForm.description.trim() || !eventForm.event_date || !eventForm.event_time || !eventForm.location.trim() || submittingEvent}
                className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {submittingEvent ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Event'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Event Modal */}
      <Dialog open={showEditEvent} onOpenChange={setShowEditEvent}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-center text-white">Edit Event</DialogTitle>
            <DialogDescription className="text-center text-slate-400">
              Update your event details
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-slate-300">Event Title</Label>
              <Input
                placeholder="What's your event called?"
                value={eventForm.title}
                onChange={(e) => setEventForm({...eventForm, title: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">Description</Label>
              <Textarea
                placeholder="Tell people more about your event..."
                value={eventForm.description}
                onChange={(e) => setEventForm({...eventForm, description: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 resize-none min-h-[100px] focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-slate-300">Date</Label>
                <Input
                  type="date"
                  value={eventForm.event_date}
                  min={getMinDate()}
                  onChange={(e) => setEventForm({...eventForm, event_date: e.target.value})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Time</Label>
                <Input
                  type="time"
                  value={eventForm.event_time}
                  onChange={(e) => setEventForm({...eventForm, event_time: e.target.value})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-slate-300">Location</Label>
              <Input
                placeholder="Where is your event?"
                value={eventForm.location}
                onChange={(e) => setEventForm({...eventForm, location: e.target.value})}
                disabled={submittingEvent}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-slate-300">Max Attendees</Label>
                <Input
                  type="number"
                  min={editingEvent?.attending_count || 1}
                  max="1000"
                  value={eventForm.max_attendees}
                  onChange={(e) => setEventForm({...eventForm, max_attendees: parseInt(e.target.value) || 50})}
                  disabled={submittingEvent}
                  className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {editingEvent && (
                  <p className="text-xs text-slate-400">
                    Cannot reduce below current attendees ({editingEvent.attending_count})
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Category</Label>
                <Select 
                  value={eventForm.category} 
                  onValueChange={(value) => setEventForm({...eventForm, category: value})}
                  disabled={submittingEvent}
                >
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="social">Social</SelectItem>
                    <SelectItem value="ceremony">Ceremony</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="community">Community</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {imagePreview && (
              <div className="relative">
                <div className="rounded-lg overflow-hidden border border-slate-600">
                  <img 
                    src={imagePreview} 
                    alt="Event cover" 
                    className="w-full h-32 object-cover"
                  />
                </div>
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute top-2 right-2 w-8 h-8 p-0 rounded-full"
                  onClick={removeImage}
                  disabled={submittingEvent}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  className="hidden"
                  disabled={submittingEvent}
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={submittingEvent}
                  className="text-slate-300 hover:text-white hover:bg-slate-700"
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  {imagePreview ? 'Change Cover' : 'Add Cover'}
                </Button>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowEditEvent(false);
                    setEditingEvent(null);
                    resetForm();
                  }}
                  disabled={submittingEvent}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleEditEvent}
                  disabled={!eventForm.title.trim() || !eventForm.description.trim() || !eventForm.event_date || !eventForm.event_time || !eventForm.location.trim() || submittingEvent}
                  className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingEvent ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    'Update Event'
                  )}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="bg-slate-800 border-slate-700 text-white max-w-sm mx-auto">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Event</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              Are you sure you want to delete this event? This action cannot be undone and will notify all attendees.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              className="bg-slate-700 text-white border-slate-600 hover:bg-slate-600"
              disabled={deletingEventId !== null}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => eventToDelete && handleDeleteEvent(eventToDelete)}
              disabled={deletingEventId !== null}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deletingEventId ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="bg-slate-800 border-b border-slate-700">
          <TabsList className="grid w-full grid-cols-2 rounded-none bg-transparent h-12">
            <TabsTrigger 
              value="upcoming" 
              className="rounded-none data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white text-slate-300 hover:text-white transition-all duration-200"
            >
              Upcoming
            </TabsTrigger>
            <TabsTrigger 
              value="my-events" 
              className="rounded-none data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white text-slate-300 hover:text-white transition-all duration-200"
            >
              My Events ({myEvents.length})
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="flex-1 overflow-hidden bg-gradient-to-b from-slate-900 to-slate-800">
          <TabsContent value="upcoming" className="h-full m-0">
            <div className="h-full overflow-y-auto">
              <div className="space-y-0">
                {events.length === 0 ? (
                  <div className="text-center text-slate-400 mt-8 p-4">
                    <Calendar className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No upcoming events. Create the first one!</p>
                  </div>
                ) : (
                  events.map((event, index) => {
                    const userStatus = userRSVPs[event.id] || 'not_going';
                    const isFeatured = index === 0; // Make first event featured for demo
                    const isOwner = isEventOwner(event);
                    
                    return (
                      <Card key={event.id} className="rounded-none border-0 border-b border-slate-700/30 bg-slate-800/30 backdrop-blur-sm hover:bg-slate-700/30 transition-all duration-200">
                        <CardContent className="p-4 relative">
                          {/* Featured event decoration */}
                          {isFeatured && (
                            <>
                              <div className="absolute top-2 right-2">
                                <Star className="w-5 h-5 text-yellow-400 fill-current" />
                              </div>
                              <div className="absolute left-0 top-0 w-1 h-full bg-gradient-to-b from-yellow-500 to-orange-500"></div>
                            </>
                          )}
                          
                          {/* Random decorative elements */}
                          {index % 2 === 0 && (
                            <div className="absolute top-4 right-4 opacity-10">
                              <Sparkles className="w-6 h-6 text-blue-400" />
                            </div>
                          )}
                          
                          <div className="space-y-3">
                            {/* Cover Image */}
                            {event.cover_image && (
                              <div className="rounded-lg overflow-hidden border border-slate-600/30">
                                <img 
                                  src={event.cover_image} 
                                  alt="Event cover"
                                  className="w-full h-32 object-cover"
                                />
                              </div>
                            )}

                            {/* Event Header */}
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h3 className="font-medium text-white mb-2 leading-tight">{event.title}</h3>
                                <Badge className={`${getCategoryColor(event.category)} border`}>
                                  {event.category}
                                </Badge>
                              </div>
                              
                              {/* Edit/Delete Options for own events */}
                              {isOwner && (
                                <div className="relative z-50">
                                  <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        className="w-8 h-8 p-0 text-slate-400 hover:text-white hover:bg-slate-700/50 rounded-full"
                                      >
                                        <MoreHorizontal className="w-4 h-4" />
                                      </Button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent 
                                      align="end" 
                                      className="bg-slate-800 border-slate-700 text-white z-[100] min-w-[140px]"
                                      sideOffset={5}
                                    >
                                      <DropdownMenuItem
                                        onClick={() => openEditEvent(event)}
                                        className="text-blue-400 hover:text-blue-300 hover:bg-slate-700 cursor-pointer focus:bg-slate-700 focus:text-blue-300"
                                      >
                                        <Edit3 className="w-4 h-4 mr-2" />
                                        Edit Event
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() => confirmDeleteEvent(event.id)}
                                        className="text-red-400 hover:text-red-300 hover:bg-slate-700 cursor-pointer focus:bg-slate-700 focus:text-red-300"
                                      >
                                        <Trash2 className="w-4 h-4 mr-2" />
                                        Delete Event
                                      </DropdownMenuItem>
                                    </DropdownMenuContent>
                                  </DropdownMenu>
                                </div>
                              )}
                            </div>

                            {/* Event Details with icons */}
                            <div className="space-y-3 text-sm">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center">
                                  <Calendar className="w-4 h-4 text-blue-400" />
                                </div>
                                <span className="text-slate-300">{formatDate(event.event_date)}</span>
                                <div className="w-8 h-8 bg-purple-500/20 rounded-full flex items-center justify-center ml-2">
                                  <Clock className="w-4 h-4 text-purple-400" />
                                </div>
                                <span className="text-slate-300">{formatTime(event.event_time)}</span>
                              </div>
                              
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                                  <MapPin className="w-4 h-4 text-green-400" />
                                </div>
                                <span className="text-slate-300">{event.location}</span>
                              </div>
                              
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 bg-orange-500/20 rounded-full flex items-center justify-center">
                                  <Users className="w-4 h-4 text-orange-400" />
                                </div>
                                <span className="text-slate-300">{event.attending_count}/{event.max_attendees} attending</span>
                                <div className="flex-1 bg-slate-700 rounded-full h-2 ml-2">
                                  <div 
                                    className="bg-gradient-to-r from-orange-500 to-red-500 h-2 rounded-full transition-all duration-300"
                                    style={{ width: `${Math.min((event.attending_count / event.max_attendees) * 100, 100)}%` }}
                                  ></div>
                                </div>
                              </div>
                            </div>

                            {/* Host */}
                            <div className="flex items-center gap-3">
                              <Avatar className="w-8 h-8 ring-2 ring-blue-500/30">
                                <AvatarFallback className="bg-gradient-to-r from-slate-600 to-slate-700 text-white text-xs">
                                  {event.host_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm text-slate-400">
                                Hosted by <span className="text-slate-300">{event.host_name}</span>
                                {isOwner && <span className="text-blue-400 ml-1">(You)</span>}
                              </span>
                            </div>

                            {/* Description */}
                            <p className="text-sm text-slate-300 leading-relaxed bg-slate-700/30 rounded-lg p-3 border border-slate-600/30">
                              {event.description}
                            </p>

                            {/* RSVP Buttons - Hide for own events */}
                            {!isOwner && (
                              <div className="flex items-center gap-3 pt-2">
                                <Button 
                                  variant={userStatus === 'going' ? "default" : "outline"} 
                                  size="sm"
                                  className={`transition-all duration-200 ${
                                    userStatus === 'going' 
                                      ? "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white shadow-lg shadow-green-500/20" 
                                      : "border-slate-600 text-slate-300 hover:bg-slate-700/50 hover:text-white hover:border-slate-500"
                                  }`}
                                  onClick={() => handleRSVP(event.id, userStatus === 'going' ? 'not_going' : 'going')}
                                >
                                  {userStatus === 'going' ? 'Going ✓' : 'RSVP'}
                                </Button>
                                <Button 
                                  variant={userStatus === 'interested' ? "default" : "outline"} 
                                  size="sm"
                                  className={`transition-all duration-200 ${
                                    userStatus === 'interested' 
                                      ? "bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow-lg shadow-blue-500/20" 
                                      : "border-slate-600 text-slate-300 hover:bg-slate-700/50 hover:text-white hover:border-slate-500"
                                  }`}
                                  onClick={() => handleRSVP(event.id, userStatus === 'interested' ? 'not_going' : 'interested')}
                                >
                                  {userStatus === 'interested' ? 'Interested ★' : 'Maybe'}
                                </Button>
                                {event.interested_count > 0 && (
                                  <span className="text-xs text-slate-500">
                                    +{event.interested_count} interested
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="my-events" className="h-full m-0">
            <div className="h-full overflow-y-auto">
              {myEvents.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-slate-500 relative">
                  <div className="absolute inset-0 bg-gradient-radial from-slate-800/50 to-transparent"></div>
                  <div className="relative z-10 text-center">
                    <Calendar className="w-16 h-16 mb-4 text-slate-600 mx-auto" />
                    <h3 className="text-lg font-medium mb-2 text-slate-400">No events yet</h3>
                    <p className="text-center text-sm text-slate-500">RSVP to upcoming events to see them here</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-0">
                  {myEvents.map((event) => (
                    <Card key={event.id} className="rounded-none border-0 border-b border-slate-700/30 bg-slate-800/30 backdrop-blur-sm">
                      <CardContent className="p-4">
                        <div className="space-y-3">
                          {event.cover_image && (
                            <div className="rounded-lg overflow-hidden border border-slate-600/30">
                              <img 
                                src={event.cover_image} 
                                alt="Event cover"
                                className="w-full h-24 object-cover"
                              />
                            </div>
                          )}
                          
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-medium text-white mb-2">{event.title}</h3>
                              <Badge className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 text-green-300 border-green-500/30">
                                Going ✓
                              </Badge>
                            </div>
                          </div>
                          <div className="space-y-2 text-sm text-slate-300">
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-blue-400" />
                              <span>{formatDate(event.event_date)}</span>
                              <Clock className="w-4 h-4 ml-4 text-purple-400" />
                              <span>{formatTime(event.event_time)}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-green-400" />
                              <span>{event.location}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}