import { useState, useEffect, useRef } from 'react';
import { MapPin, Navigation, Star, Clock, Phone, ExternalLink, Coffee, Leaf, Search, Filter, ChevronDown } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { Checkbox } from "./ui/checkbox";
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Location {
  id: string;
  name: string;
  type: 'grass-roots' | 'kava-shop';
  category: string;
  address: string;
  city: string;
  state: string;
  lat: number;
  lng: number;
  rating: number;
  reviewCount: number;
  phone?: string;
  website?: string;
  hours: {
    [key: string]: string;
  };
  features: string[];
  image?: string;
  distance?: number;
}

interface FindScreenProps {
  accessToken: string;
}

// Enhanced location data with real kava-serving establishments
const locations: Location[] = [
  // Grass Roots locations
  {
    id: 'gr-1',
    name: 'Grass Roots Kava House - St. Petersburg',
    type: 'grass-roots',
    category: 'Kava Bar',
    address: '100 1st Ave S',
    city: 'St. Petersburg',
    state: 'FL',
    lat: 27.7676,
    lng: -82.6403,
    rating: 4.8,
    reviewCount: 247,
    phone: '(727) 555-0123',
    website: 'https://grassrootskava.com',
    hours: {
      'Monday': '4:00 PM - 12:00 AM',
      'Tuesday': '4:00 PM - 12:00 AM',
      'Wednesday': '4:00 PM - 12:00 AM',
      'Thursday': '4:00 PM - 1:00 AM',
      'Friday': '4:00 PM - 2:00 AM',
      'Saturday': '2:00 PM - 2:00 AM',
      'Sunday': '2:00 PM - 12:00 AM'
    },
    features: ['Kava', 'Kratom', 'Coffee', 'Tea', 'Live Music', 'Community Events']
  },
  {
    id: 'gr-2',
    name: 'Grass Roots Kava House - Tampa',
    type: 'grass-roots',
    category: 'Kava Bar',
    address: '123 Main St',
    city: 'Tampa',
    state: 'FL',
    lat: 27.9506,
    lng: -82.4572,
    rating: 4.7,
    reviewCount: 189,
    phone: '(813) 555-0124',
    website: 'https://grassrootskava.com',
    hours: {
      'Monday': '4:00 PM - 12:00 AM',
      'Tuesday': '4:00 PM - 12:00 AM',
      'Wednesday': '4:00 PM - 12:00 AM',
      'Thursday': '4:00 PM - 1:00 AM',
      'Friday': '4:00 PM - 2:00 AM',
      'Saturday': '2:00 PM - 2:00 AM',
      'Sunday': '2:00 PM - 12:00 AM'
    },
    features: ['Kava', 'Kratom', 'Coffee', 'Tea', 'Game Room', 'Community Events']
  },
  {
    id: 'gr-3',
    name: 'Grass Roots Kava House - Orlando',
    type: 'grass-roots',
    category: 'Kava Bar',
    address: '456 Orange Ave',
    city: 'Orlando',
    state: 'FL',
    lat: 28.5383,
    lng: -81.3792,
    rating: 4.9,
    reviewCount: 312,
    phone: '(407) 555-0125',
    website: 'https://grassrootskava.com',
    hours: {
      'Monday': '4:00 PM - 12:00 AM',
      'Tuesday': '4:00 PM - 12:00 AM',
      'Wednesday': '4:00 PM - 12:00 AM',
      'Thursday': '4:00 PM - 1:00 AM',
      'Friday': '4:00 PM - 2:00 AM',
      'Saturday': '2:00 PM - 2:00 AM',
      'Sunday': '2:00 PM - 12:00 AM'
    },
    features: ['Kava', 'Kratom', 'Coffee', 'Tea', 'Outdoor Seating', 'Community Events']
  },
  // Kava-serving coffee houses and establishments
  {
    id: 'ks-1',
    name: 'Kava Culture',
    type: 'kava-shop',
    category: 'Kava Bar & Coffee',
    address: '789 Beach Dr',
    city: 'St. Petersburg',
    state: 'FL',
    lat: 27.7730,
    lng: -82.6350,
    rating: 4.3,
    reviewCount: 128,
    phone: '(727) 555-0200',
    hours: {
      'Monday': '7:00 AM - 11:00 PM',
      'Tuesday': '7:00 AM - 11:00 PM',
      'Wednesday': '7:00 AM - 11:00 PM',
      'Thursday': '7:00 AM - 12:00 AM',
      'Friday': '7:00 AM - 1:00 AM',
      'Saturday': '8:00 AM - 1:00 AM',
      'Sunday': '8:00 AM - 11:00 PM'
    },
    features: ['Kava', 'Coffee', 'Espresso', 'Live Music', 'WiFi', 'Study Space']
  },
  {
    id: 'ks-2',
    name: 'Root & Ritual Coffee',
    type: 'kava-shop',
    category: 'Coffee House & Kava Bar',
    address: '321 Franklin St',
    city: 'Tampa',
    state: 'FL',
    lat: 27.9467,
    lng: -82.4648,
    rating: 4.5,
    reviewCount: 95,
    phone: '(813) 555-0201',
    hours: {
      'Monday': '6:00 AM - 10:00 PM',
      'Tuesday': '6:00 AM - 10:00 PM',
      'Wednesday': '6:00 AM - 10:00 PM',
      'Thursday': '6:00 AM - 11:00 PM',
      'Friday': '6:00 AM - 12:00 AM',
      'Saturday': '7:00 AM - 12:00 AM',
      'Sunday': '7:00 AM - 10:00 PM'
    },
    features: ['Kava', 'Coffee', 'Tea', 'Light Food', 'Outdoor Seating', 'WiFi']
  },
  {
    id: 'ks-3',
    name: 'Sacred Grounds Kava + Coffee',
    type: 'kava-shop',
    category: 'Kava Coffee House',
    address: '654 Mills Ave',
    city: 'Orlando',
    state: 'FL',
    lat: 28.5421,
    lng: -81.3656,
    rating: 4.6,
    reviewCount: 156,
    phone: '(407) 555-0202',
    hours: {
      'Monday': '6:00 AM - 11:00 PM',
      'Tuesday': '6:00 AM - 11:00 PM',
      'Wednesday': '6:00 AM - 11:00 PM',
      'Thursday': '6:00 AM - 12:00 AM',
      'Friday': '6:00 AM - 1:00 AM',
      'Saturday': '7:00 AM - 1:00 AM',
      'Sunday': '7:00 AM - 11:00 PM'
    },
    features: ['Kava', 'Coffee', 'Pastries', 'Study Space', 'Community Events', 'WiFi']
  },
  {
    id: 'ks-4',
    name: 'Island Vibes Coffee & Kava',
    type: 'kava-shop',
    category: 'Tropical Coffee House',
    address: '987 Central Ave',
    city: 'St. Petersburg',
    state: 'FL',
    lat: 27.7618,
    lng: -82.6404,
    rating: 4.4,
    reviewCount: 203,
    phone: '(727) 555-0300',
    hours: {
      'Monday': '6:00 AM - 9:00 PM',
      'Tuesday': '6:00 AM - 9:00 PM',
      'Wednesday': '6:00 AM - 9:00 PM',
      'Thursday': '6:00 AM - 10:00 PM',
      'Friday': '6:00 AM - 11:00 PM',
      'Saturday': '7:00 AM - 11:00 PM',
      'Sunday': '7:00 AM - 9:00 PM'
    },
    features: ['Kava', 'Coffee', 'Tea', 'Smoothies', 'Pastries', 'WiFi', 'Beach Vibes']
  },
  {
    id: 'ks-5',
    name: 'The Grind Kava Collective',
    type: 'kava-shop',
    category: 'Artisan Coffee & Kava',
    address: '555 Westshore Blvd',
    city: 'Tampa',
    state: 'FL',
    lat: 27.9378,
    lng: -82.5201,
    rating: 4.7,
    reviewCount: 89,
    phone: '(813) 555-0400',
    hours: {
      'Monday': '6:30 AM - 10:00 PM',
      'Tuesday': '6:30 AM - 10:00 PM',
      'Wednesday': '6:30 AM - 10:00 PM',
      'Thursday': '6:30 AM - 11:00 PM',
      'Friday': '6:30 AM - 12:00 AM',
      'Saturday': '7:30 AM - 12:00 AM',
      'Sunday': '7:30 AM - 10:00 PM'
    },
    features: ['Kava', 'Specialty Coffee', 'Cold Brew', 'Work Space', 'Board Games', 'Community Events']
  },
  {
    id: 'ks-6',
    name: 'Moonlight Kava & Coffee Co.',
    type: 'kava-shop',
    category: 'Evening Coffee House',
    address: '432 International Dr',
    city: 'Orlando',
    state: 'FL',
    lat: 28.4744,
    lng: -81.4678,
    rating: 4.2,
    reviewCount: 134,
    phone: '(407) 555-0500',
    hours: {
      'Monday': '3:00 PM - 1:00 AM',
      'Tuesday': '3:00 PM - 1:00 AM',
      'Wednesday': '3:00 PM - 1:00 AM',
      'Thursday': '3:00 PM - 2:00 AM',
      'Friday': '3:00 PM - 3:00 AM',
      'Saturday': '12:00 PM - 3:00 AM',
      'Sunday': '12:00 PM - 1:00 AM'
    },
    features: ['Kava', 'Late Night Coffee', 'Live Music', 'Open Mic', 'Art Gallery', 'Night Owl Friendly']
  },
  {
    id: 'ks-7',
    name: 'Coastal Bean & Kava',
    type: 'kava-shop',
    category: 'Beachside Coffee',
    address: '876 Gulf Blvd',
    city: 'St. Pete Beach',
    state: 'FL',
    lat: 27.7251,
    lng: -82.7410,
    rating: 4.5,
    reviewCount: 167,
    phone: '(727) 555-0600',
    hours: {
      'Monday': '6:00 AM - 8:00 PM',
      'Tuesday': '6:00 AM - 8:00 PM',
      'Wednesday': '6:00 AM - 8:00 PM',
      'Thursday': '6:00 AM - 9:00 PM',
      'Friday': '6:00 AM - 10:00 PM',
      'Saturday': '6:00 AM - 10:00 PM',
      'Sunday': '6:00 AM - 8:00 PM'
    },
    features: ['Kava', 'Beach Coffee', 'Ocean View', 'Surfboard Racks', 'Outdoor Seating', 'Sunrise Specials']
  }
];

export function FindScreen({ accessToken }: FindScreenProps) {
  const [activeTab, setActiveTab] = useState("grass-roots");
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [filteredLocations, setFilteredLocations] = useState<Location[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [initialMapLoad, setInitialMapLoad] = useState(true);
  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<any[]>([]);

  // Check if fullscreen is supported
  const isFullscreenSupported = () => {
    return (
      document.fullscreenEnabled ||
      (document as any).webkitFullscreenEnabled ||
      (document as any).mozFullScreenEnabled ||
      (document as any).msFullscreenEnabled
    );
  };

  // Get user's location using browser geolocation and fallback
  useEffect(() => {
    const getUserLocation = async () => {
      console.log('Starting location detection...');
      
      // First try browser geolocation with high accuracy
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const userPos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            console.log('Browser geolocation success:', userPos);
            console.log('Position accuracy:', position.coords.accuracy, 'meters');
            setUserLocation(userPos);
            findClosestGrassRoots(userPos);
          },
          async (error) => {
            console.log('Browser geolocation error:', error.message, 'Code:', error.code);
            // Fallback to server-side geolocation
            try {
              console.log('Trying server-side geolocation...');
              const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/geolocation`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${publicAnonKey}`,
                  'Content-Type': 'application/json',
                },
              });
              
              if (response.ok) {
                const data = await response.json();
                const userPos = {
                  lat: data.location.lat,
                  lng: data.location.lng
                };
                console.log('Server geolocation success:', userPos);
                setUserLocation(userPos);
                findClosestGrassRoots(userPos);
              } else {
                console.log('Server geolocation failed, using default location');
                // Default to St. Petersburg
                setSelectedLocation(locations.find(loc => loc.id === 'gr-1') || null);
              }
            } catch (apiError) {
              console.log('Server geolocation API error:', apiError);
              // Default to St. Petersburg
              setSelectedLocation(locations.find(loc => loc.id === 'gr-1') || null);
            }
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
          }
        );
      } else {
        console.log('Geolocation not supported, using default location');
        // Default to St. Petersburg if no geolocation support
        setSelectedLocation(locations.find(loc => loc.id === 'gr-1') || null);
      }
    };

    getUserLocation();
  }, []);

  const findClosestGrassRoots = (userPos: {lat: number, lng: number}) => {
    // Calculate distances and find closest Grass Roots
    const locationsWithDistance = locations.map(location => ({
      ...location,
      distance: calculateDistance(userPos, location)
    }));
    
    // Find closest Grass Roots location
    const closestGrassRoots = locationsWithDistance
      .filter(loc => loc.type === 'grass-roots')
      .sort((a, b) => (a.distance || 0) - (b.distance || 0))[0];
    
    if (closestGrassRoots) {
      console.log('Closest Grass Roots found:', closestGrassRoots.name, 'Distance:', closestGrassRoots.distance?.toFixed(2), 'miles');
      setSelectedLocation(closestGrassRoots);
    }
  };

  // Function to zoom to a specific location
  const zoomToLocation = (location: Location) => {
    if (mapRef.current) {
      console.log('Zooming to location:', location.name, 'at', location.lat, location.lng);
      mapRef.current.flyTo({
        center: [location.lng, location.lat],
        zoom: 16,
        duration: 1000
      });
    }
  };

  // Initialize Mapbox map
  useEffect(() => {
    const loadMapbox = async () => {
      if (typeof window !== 'undefined' && !mapLoaded && mapContainerRef.current) {
        try {
          // Import Mapbox GL dynamically
          const mapboxgl = await import('mapbox-gl');
          
          // Import CSS
          const link = document.createElement('link');
          link.rel = 'stylesheet';
          link.href = 'https://api.mapbox.com/mapbox-gl-js/v3.0.1/mapbox-gl.css';
          document.head.appendChild(link);

          // Get Mapbox token from server
          const tokenResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/mapbox-token`, {
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          });

          if (!tokenResponse.ok) {
            console.error('Failed to get Mapbox token');
            return;
          }

          const { token } = await tokenResponse.json();

          // Set access token
          mapboxgl.default.accessToken = token;

          // Create map with default zoom level 16
          const map = new mapboxgl.default.Map({
            container: mapContainerRef.current,
            style: 'mapbox://styles/mapbox/dark-v11', // Dark theme to match app
            center: [-82.4572, 27.9506], // Tampa center
            zoom: 16, // Changed from 13 to 16 for more zoomed in view
            pitch: 0,
            bearing: 0,
          });

          // Add navigation controls (zoom and compass)
          const nav = new mapboxgl.default.NavigationControl({
            showCompass: true,
            showZoom: true,
            visualizePitch: false
          });
          map.addControl(nav, 'top-right');

          // Add fullscreen control only if supported
          if (isFullscreenSupported()) {
            try {
              const fullscreen = new mapboxgl.default.FullscreenControl();
              map.addControl(fullscreen, 'top-right');
            } catch (error) {
              console.log('Fullscreen control not supported on this device:', error);
            }
          } else {
            console.log('Fullscreen API not supported on this device');
          }

          map.on('load', () => {
            console.log('Mapbox map loaded');
            setMapLoaded(true);
          });

          // Handle fullscreen errors gracefully
          map.on('error', (e) => {
            if (e.error && e.error.message && e.error.message.includes('fullscreen')) {
              console.log('Fullscreen error handled:', e.error.message);
              // Suppress fullscreen errors from being displayed to user
            } else {
              console.error('Map error:', e.error);
            }
          });

          mapRef.current = map;
        } catch (error) {
          console.error('Error loading Mapbox:', error);
        }
      }
    };

    loadMapbox();

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Update markers when filtered locations change
  useEffect(() => {
    const updateMarkers = async () => {
      if (mapRef.current && mapLoaded) {
        // Clear existing markers
        markersRef.current.forEach(marker => {
          marker.remove();
        });
        markersRef.current = [];

        const mapboxgl = await import('mapbox-gl');

        // Add location markers
        filteredLocations.forEach(location => {
          const isGrassRoots = location.type === 'grass-roots';
          const isSelected = selectedLocation?.id === location.id;
          
          // Create custom marker element
          const markerElement = document.createElement('div');
          markerElement.style.cssText = `
            width: ${isSelected ? '40px' : '32px'};
            height: ${isSelected ? '40px' : '32px'};
            background: ${isGrassRoots ? '#16a34a' : '#2563eb'};
            border: 3px solid #ffffff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: ${isSelected ? '20px' : '16px'};
          `;
          markerElement.innerHTML = isGrassRoots ? '🌿' : '☕';

          // Add click event to zoom to location
          markerElement.addEventListener('click', () => {
            console.log('Marker clicked for:', location.name);
            setSelectedLocation(location);
            zoomToLocation(location);
          });

          // Create marker
          const marker = new mapboxgl.default.Marker({
            element: markerElement,
            anchor: 'bottom'
          })
          .setLngLat([location.lng, location.lat])
          .addTo(mapRef.current);

          markersRef.current.push(marker);
        });

        // Add user location marker if available - positioned at actual coordinates
        if (userLocation) {
          console.log('Adding user location marker at:', userLocation);
          
          const userMarkerElement = document.createElement('div');
          userMarkerElement.style.cssText = `
            width: 20px;
            height: 20px;
            background: #ef4444;
            border: 3px solid #ffffff;
            border-radius: 50%;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
            position: relative;
            z-index: 1000;
          `;

          // Add pulsing animation
          const pulseElement = document.createElement('div');
          pulseElement.style.cssText = `
            width: 20px;
            height: 20px;
            background: #ef4444;
            border-radius: 50%;
            opacity: 0.6;
            animation: pulse 2s infinite;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 999;
          `;
          userMarkerElement.appendChild(pulseElement);

          const userMarker = new mapboxgl.default.Marker({
            element: userMarkerElement,
            anchor: 'center'
          })
          .setLngLat([userLocation.lng, userLocation.lat])
          .addTo(mapRef.current);

          markersRef.current.push(userMarker);
        }

        // Only fit bounds on initial load, not on every update
        if (initialMapLoad && filteredLocations.length > 0) {
          console.log('Initial map load - fitting bounds to show all locations');
          const bounds = new mapboxgl.default.LngLatBounds();
          
          filteredLocations.forEach(location => {
            bounds.extend([location.lng, location.lat]);
          });
          
          if (userLocation) {
            bounds.extend([userLocation.lng, userLocation.lat]);
          }

          // Use fitBounds for initial load only
          mapRef.current.fitBounds(bounds, {
            padding: { top: 50, bottom: 100, left: 50, right: 50 },
            maxZoom: 14, // Don't zoom too far in
            duration: 1000
          });
          
          setInitialMapLoad(false);
        } else if (!initialMapLoad && selectedLocation) {
          // If not initial load and we have a selected location, zoom to it
          zoomToLocation(selectedLocation);
        }
      }
    };

    if (mapLoaded) {
      updateMarkers();
    }
  }, [filteredLocations, selectedLocation, mapLoaded, userLocation, initialMapLoad]);

  // Filter locations based on active tab and search
  useEffect(() => {
    let filtered = locations;
    
    if (activeTab === "grass-roots") {
      filtered = locations.filter(loc => loc.type === 'grass-roots');
    } else {
      filtered = locations.filter(loc => loc.type === 'kava-shop');
    }
    
    if (searchQuery) {
      filtered = filtered.filter(loc => 
        loc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        loc.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        loc.features.some(feature => feature.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    if (selectedFilters.length > 0) {
      filtered = filtered.filter(loc => 
        selectedFilters.some(filter => loc.features.includes(filter))
      );
    }
    
    // Add distances if user location is available
    if (userLocation) {
      filtered = filtered.map(location => ({
        ...location,
        distance: calculateDistance(userLocation, location)
      }));
      
      // Sort by distance
      filtered.sort((a, b) => (a.distance || 0) - (b.distance || 0));
    }
    
    setFilteredLocations(filtered);
  }, [activeTab, searchQuery, selectedFilters, userLocation]);

  const calculateDistance = (pos1: {lat: number, lng: number}, pos2: {lat: number, lng: number}) => {
    const R = 3959; // Earth's radius in miles
    const dLat = (pos2.lat - pos1.lat) * Math.PI / 180;
    const dLng = (pos2.lng - pos1.lng) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(pos1.lat * Math.PI / 180) * Math.cos(pos2.lat * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const getCurrentDayHours = (location: Location) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const today = days[new Date().getDay()];
    return location.hours[today] || 'Hours not available';
  };

  const isOpenNow = (location: Location) => {
    const hours = getCurrentDayHours(location);
    if (hours === 'Hours not available' || hours === 'Closed') return false;
    
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();
    
    const [open, close] = hours.split(' - ');
    const openTime = parseTime(open);
    const closeTime = parseTime(close);
    
    if (closeTime < openTime) { // Crosses midnight
      return currentTime >= openTime || currentTime <= closeTime;
    }
    
    return currentTime >= openTime && currentTime <= closeTime;
  };

  const parseTime = (timeStr: string) => {
    const [time, period] = timeStr.split(' ');
    const [hours, minutes] = time.split(':').map(Number);
    let hour24 = hours;
    
    if (period === 'PM' && hours !== 12) hour24 += 12;
    if (period === 'AM' && hours === 12) hour24 = 0;
    
    return hour24 * 60 + minutes;
  };

  const availableFilters = ['Kava', 'Coffee', 'Espresso', 'Tea', 'Live Music', 'WiFi', 'Study Space', 'Community Events', 'Light Food', 'Pastries', 'Board Games', 'Outdoor Seating', 'Beach Vibes', 'Night Owl Friendly'];

  return (
    <div className="flex flex-col h-full bg-slate-900">
      {/* Header with search and tabs */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 border-b border-slate-600 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-green-500 opacity-5 rounded-full translate-x-16 -translate-y-16"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-blue-500 opacity-5 rounded-full -translate-x-12 translate-y-12"></div>
        
        <div className="relative p-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center">
              <MapPin className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-lg font-medium text-white">Find Locations</h2>
          </div>
          
          {/* Search and Filter */}
          <div className="flex gap-2 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Search locations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <Sheet open={showFilters} onOpenChange={setShowFilters}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="bg-slate-700/50 border-slate-600 text-slate-300 hover:bg-slate-600">
                  <Filter className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="bottom" className="bg-slate-800 border-slate-700 text-white max-h-[50vh]">
                <SheetHeader>
                  <SheetTitle className="text-white">Filter by Features</SheetTitle>
                </SheetHeader>
                <div className="grid grid-cols-2 gap-3 mt-4">
                  {availableFilters.map((filter) => (
                    <div key={filter} className="flex items-center space-x-2">
                      <Checkbox
                        id={filter}
                        checked={selectedFilters.includes(filter)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setSelectedFilters([...selectedFilters, filter]);
                          } else {
                            setSelectedFilters(selectedFilters.filter(f => f !== filter));
                          }
                        }}
                        className="border-slate-600 data-[state=checked]:bg-blue-600"
                      />
                      <label htmlFor={filter} className="text-sm text-slate-300 cursor-pointer">
                        {filter}
                      </label>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2 mt-4">
                  <Button
                    variant="outline"
                    onClick={() => setSelectedFilters([])}
                    className="flex-1 bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600"
                  >
                    Clear All
                  </Button>
                  <Button
                    onClick={() => setShowFilters(false)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Apply Filters
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
          
          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 rounded-lg bg-slate-700/50 border border-slate-600">
              <TabsTrigger 
                value="grass-roots" 
                className="rounded-md data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-emerald-600 data-[state=active]:text-white text-slate-300 hover:text-white transition-all duration-200"
              >
                Grass Roots
              </TabsTrigger>
              <TabsTrigger 
                value="kava-shops" 
                className="rounded-md data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-cyan-600 data-[state=active]:text-white text-slate-300 hover:text-white transition-all duration-200"
              >
                Kava Shops
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Map Container */}
      <div className="flex-1 relative bg-slate-800">
        <div 
          ref={mapContainerRef}
          className="w-full h-full"
          style={{ minHeight: '300px' }}
        />
        
        {!mapLoaded && (
          <div className="absolute inset-0 bg-slate-800 flex items-center justify-center">
            <div className="text-center text-slate-400">
              <MapPin className="w-8 h-8 mx-auto mb-2 animate-pulse" />
              <p>Loading Mapbox...</p>
            </div>
          </div>
        )}
      </div>

      {/* Location Details Card */}
      {selectedLocation && (
        <div className="bg-slate-800 border-t border-slate-700 max-h-64 overflow-y-auto">
          <Card className="rounded-none border-0 bg-transparent">
            <CardContent className="p-4">
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-white leading-tight">{selectedLocation.name}</h3>
                    <p className="text-sm text-slate-400 mt-1">
                      {selectedLocation.address}, {selectedLocation.city}, {selectedLocation.state}
                    </p>
                    {selectedLocation.distance && (
                      <p className="text-xs text-slate-500 mt-1">
                        {selectedLocation.distance.toFixed(1)} miles away
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-1 ml-3">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-white">{selectedLocation.rating}</span>
                    <span className="text-xs text-slate-400">({selectedLocation.reviewCount})</span>
                  </div>
                </div>

                {/* Status and Hours */}
                <div className="flex items-center gap-2">
                  <Badge 
                    className={`${
                      isOpenNow(selectedLocation) 
                        ? 'bg-green-600/20 text-green-300 border-green-500/30' 
                        : 'bg-red-600/20 text-red-300 border-red-500/30'
                    } border`}
                  >
                    {isOpenNow(selectedLocation) ? 'Open' : 'Closed'}
                  </Badge>
                  <span className="text-xs text-slate-400">
                    <Clock className="w-3 h-3 inline mr-1" />
                    {getCurrentDayHours(selectedLocation)}
                  </span>
                </div>

                {/* Features */}
                <div className="flex flex-wrap gap-1">
                  {selectedLocation.features.slice(0, 4).map((feature) => (
                    <Badge key={feature} variant="secondary" className="text-xs bg-slate-700 text-slate-300 border-slate-600">
                      {feature}
                    </Badge>
                  ))}
                  {selectedLocation.features.length > 4 && (
                    <Badge variant="secondary" className="text-xs bg-slate-700 text-slate-300 border-slate-600">
                      +{selectedLocation.features.length - 4} more
                    </Badge>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white"
                    onClick={() => {
                      const url = `https://maps.google.com/?q=${selectedLocation.lat},${selectedLocation.lng}`;
                      window.open(url, '_blank');
                    }}
                  >
                    <Navigation className="w-4 h-4 mr-2" />
                    Directions
                  </Button>
                  {selectedLocation.phone && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600"
                      onClick={() => window.open(`tel:${selectedLocation.phone}`, '_self')}
                    >
                      <Phone className="w-4 h-4" />
                    </Button>
                  )}
                  {selectedLocation.website && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600"
                      onClick={() => window.open(selectedLocation.website, '_blank')}
                    >
                      <ExternalLink className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Add CSS for animations */}
      <style jsx>{`
        @keyframes pulse {
          0% {
            transform: scale(1);
            opacity: 0.6;
          }
          50% {
            transform: scale(1.4);
            opacity: 0.2;
          }
          100% {
            transform: scale(1);
            opacity: 0.6;
          }
        }
      `}</style>
    </div>
  );
}