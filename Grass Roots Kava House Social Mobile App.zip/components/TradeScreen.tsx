import { useState, useEffect, useRef } from 'react';
import { Plus, Search, Filter, Image as ImageIcon, X, MoreHorizontal, Trash2, MessageCircle, Eye, ArrowLeft, Send, Loader2 } from 'lucide-react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "./ui/alert-dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { Alert, AlertDescription } from "./ui/alert";
import { ScrollArea } from "./ui/scroll-area";
import { projectId } from "../utils/supabase/info";

interface TradePost {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  item_name: string;
  item_description: string;
  category: string;
  price: string;
  condition: string;
  images: string[];
  chat_count: number;
  views: number;
  created_at: string;
  updated_at: string;
}

interface ChatMessage {
  id: string;
  trade_post_id: string;
  user_id: string;
  user_name: string;
  content: string;
  is_poster: boolean;
  created_at: string;
}

interface TradeScreenProps {
  accessToken: string;
}

export function TradeScreen({ accessToken }: TradeScreenProps) {
  const [posts, setPosts] = useState<TradePost[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [selectedPost, setSelectedPost] = useState<TradePost | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);
  
  // Create post form states
  const [itemName, setItemName] = useState("");
  const [itemDescription, setItemDescription] = useState("");
  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [condition, setCondition] = useState("");
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [submittingPost, setSubmittingPost] = useState(false);
  
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [deletingPostId, setDeletingPostId] = useState<string | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [postToDelete, setPostToDelete] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const categories = [
    "Electronics", "Clothing", "Home & Garden", "Sports & Outdoors", 
    "Books & Media", "Instruments", "Art & Crafts", "Health & Beauty", "Other"
  ];

  const conditions = ["New", "Like New", "Good", "Well Worn"];

  useEffect(() => {
    loadTradePosts();
  }, [accessToken, selectedCategory]);

  useEffect(() => {
    if (showChat && selectedPost) {
      loadChatMessages();
      const interval = setInterval(loadChatMessages, 5000); // Poll every 5 seconds
      return () => clearInterval(interval);
    }
  }, [showChat, selectedPost]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages]);

  const loadTradePosts = async () => {
    try {
      const url = new URL(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/trade/posts`);
      if (selectedCategory !== 'all') {
        url.searchParams.append('category', selectedCategory);
      }
      
      const response = await fetch(url.toString(), {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to load trade posts');
        return;
      }

      setPosts(data.posts);
    } catch (err) {
      setError('Failed to load trade posts');
      console.error('Load trade posts error:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadChatMessages = async () => {
    if (!selectedPost) return;
    
    setChatLoading(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/trade/posts/${selectedPost.id}/chat`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Failed to load chat messages:', data.error);
        return;
      }

      setChatMessages(data.messages);
    } catch (err) {
      console.error('Load chat messages error:', err);
    } finally {
      setChatLoading(false);
    }
  };

  const handleCreatePost = async () => {
    if (!itemName.trim() || !itemDescription.trim() || !category || !price.trim() || !condition || submittingPost) return;

    setSubmittingPost(true);
    setError("");

    try {
      // Convert images to base64
      const images = [];
      for (const file of selectedImages) {
        const base64 = await convertFileToBase64(file);
        images.push(base64);
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/trade/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          item_name: itemName.trim(),
          item_description: itemDescription.trim(),
          category,
          price: price.trim(),
          condition,
          images,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to create trade post');
        return;
      }

      // Clear form and close modal
      setItemName("");
      setItemDescription("");
      setCategory("");
      setPrice("");
      setCondition("");
      setSelectedImages([]);
      setImagePreviews([]);
      setShowCreatePost(false);
      setSuccess("Trade post created successfully!");
      
      // Reload posts
      await loadTradePosts();
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError('Failed to create trade post');
      console.error('Create trade post error:', err);
    } finally {
      setSubmittingPost(false);
    }
  };

  const handleDeletePost = async (postId: string) => {
    setDeletingPostId(postId);
    setError("");

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/trade/posts/${postId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to delete trade post');
        return;
      }

      // Remove post from local state
      setPosts(posts.filter(post => post.id !== postId));
      setSuccess("Trade post deleted successfully!");
      setTimeout(() => setSuccess(""), 3000);
    } catch (err) {
      setError('Failed to delete trade post');
      console.error('Delete trade post error:', err);
    } finally {
      setDeletingPostId(null);
      setShowDeleteConfirm(false);
      setPostToDelete(null);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedPost || sendingMessage) return;

    setSendingMessage(true);
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/trade/posts/${selectedPost.id}/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          content: newMessage.trim(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to send message');
        return;
      }

      setNewMessage("");
      await loadChatMessages();
    } catch (err) {
      setError('Failed to send message');
      console.error('Send message error:', err);
    } finally {
      setSendingMessage(false);
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    if (selectedImages.length + files.length > 5) {
      setError('Maximum 5 images allowed');
      return;
    }

    for (const file of files) {
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        setError('File too large. Maximum size is 5MB per image.');
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        setError('Please select only image files.');
        return;
      }
    }

    const newImages = [...selectedImages, ...files];
    const newPreviews = [...imagePreviews];

    for (const file of files) {
      const previewUrl = URL.createObjectURL(file);
      newPreviews.push(previewUrl);
    }

    setSelectedImages(newImages);
    setImagePreviews(newPreviews);
    setError("");
  };

  const removeImage = (index: number) => {
    const newImages = selectedImages.filter((_, i) => i !== index);
    const newPreviews = imagePreviews.filter((_, i) => i !== index);
    
    // Revoke the object URL to prevent memory leaks
    URL.revokeObjectURL(imagePreviews[index]);
    
    setSelectedImages(newImages);
    setImagePreviews(newPreviews);
  };

  const confirmDeletePost = (postId: string) => {
    setPostToDelete(postId);
    setShowDeleteConfirm(true);
  };

  const getCurrentUserId = () => {
    try {
      const payload = JSON.parse(atob(accessToken.split('.')[1]));
      return payload.sub || "current-user";
    } catch {
      return "current-user";
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'New': return 'bg-green-500/20 text-green-400';
      case 'Like New': return 'bg-blue-500/20 text-blue-400';
      case 'Good': return 'bg-yellow-500/20 text-yellow-400';
      case 'Well Worn': return 'bg-orange-500/20 text-orange-400';
      default: return 'bg-slate-500/20 text-slate-400';
    }
  };

  const filteredPosts = posts.filter(post =>
    post.item_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.item_description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="h-full bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-slate-400 mx-auto mb-4 animate-spin" />
          <p className="text-slate-400">Loading trade posts...</p>
        </div>
      </div>
    );
  }

  // Chat view
  if (showChat && selectedPost) {
    return (
      <div className="flex flex-col h-full bg-slate-900">
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-4 border-b border-slate-600">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowChat(false)}
              className="text-slate-300 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex-1">
              <h3 className="text-white font-medium">{selectedPost.item_name}</h3>
              <p className="text-slate-400 text-sm">Chat with {selectedPost.user_name}</p>
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <ScrollArea className="flex-1 p-4">
          {chatLoading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-6 h-6 text-slate-400 animate-spin" />
            </div>
          ) : (
            <div className="space-y-4">
              {chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.user_id === getCurrentUserId() ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] ${
                    message.user_id === getCurrentUserId()
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-slate-200'
                  } rounded-lg p-3`}>
                    {message.user_id !== getCurrentUserId() && (
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-medium">{message.user_name}</span>
                        {message.is_poster && (
                          <Badge className="text-xs bg-green-600 text-white">OP</Badge>
                        )}
                      </div>
                    )}
                    <p className="text-sm">{message.content}</p>
                    <p className="text-xs opacity-70 mt-1">{formatTime(message.created_at)}</p>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          )}
        </ScrollArea>

        {/* Message Input */}
        <div className="p-4 border-t border-slate-700">
          <div className="flex gap-2">
            <Input
              placeholder="Type a message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              className="bg-slate-700 border-slate-600 text-white"
              disabled={sendingMessage}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!newMessage.trim() || sendingMessage}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {sendingMessage ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-900">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-4 border-b border-slate-600">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white text-lg font-medium">Trade Posts</h2>
          <Button
            onClick={() => setShowCreatePost(true)}
            className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Post
          </Button>
        </div>

        {/* Search and Filter */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Search items..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-slate-700/50 border-slate-600 text-white"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-32 bg-slate-700/50 border-slate-600 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-800 border-slate-700 text-white">
              <SelectItem value="all">All</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Success/Error Messages */}
      {error && (
        <Alert className="m-4 bg-red-900/20 border-red-800 text-red-200">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="m-4 bg-green-900/20 border-green-800 text-green-200">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {/* Trade Posts */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {filteredPosts.length === 0 ? (
            <div className="text-center text-slate-400 mt-8">
              <p>No trade posts found. Be the first to post an item!</p>
            </div>
          ) : (
            filteredPosts.map((post) => {
              const isOwnPost = post.user_id === getCurrentUserId();
              
              return (
                <Card key={post.id} className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-colors">
                  <CardContent className="p-4">
                    {/* Post Header */}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-gradient-to-r from-slate-600 to-slate-700 text-white">
                            {post.user_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-white font-medium">{post.user_name}</p>
                          <p className="text-slate-400 text-sm">{formatTime(post.created_at)}</p>
                        </div>
                      </div>
                      
                      {isOwnPost && (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 text-slate-400 hover:text-white">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700 text-white">
                            <DropdownMenuItem
                              onClick={() => confirmDeletePost(post.id)}
                              className="text-red-400 hover:text-red-300 hover:bg-slate-700"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete Post
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </div>

                    {/* Item Images */}
                    {post.images.length > 0 && (
                      <div className="mb-3 grid grid-cols-2 gap-2">
                        {post.images.slice(0, 4).map((image, index) => (
                          <div key={index} className="relative">
                            <img
                              src={image}
                              alt={`${post.item_name} ${index + 1}`}
                              className="w-full h-32 object-cover rounded-lg border border-slate-600"
                            />
                            {index === 3 && post.images.length > 4 && (
                              <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center">
                                <span className="text-white font-medium">+{post.images.length - 4}</span>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Item Details */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="text-white font-medium text-lg">{post.item_name}</h3>
                        <span className="text-green-400 font-medium">${post.price}</span>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className="bg-blue-500/20 text-blue-400">{post.category}</Badge>
                        <Badge className={getConditionColor(post.condition)}>{post.condition}</Badge>
                      </div>
                      
                      <p className="text-slate-300 text-sm">{post.item_description}</p>
                      
                      {/* Actions */}
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-4 text-slate-400 text-sm">
                          <span className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            {post.chat_count || 0}
                          </span>
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {post.views || 0}
                          </span>
                        </div>
                        
                        <Button
                          onClick={() => {
                            setSelectedPost(post);
                            setShowChat(true);
                          }}
                          variant="outline"
                          size="sm"
                          className="border-slate-600 text-slate-300 hover:bg-slate-700"
                        >
                          <MessageCircle className="w-4 h-4 mr-2" />
                          Chat
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </ScrollArea>

      {/* Create Post Modal */}
      <Dialog open={showCreatePost} onOpenChange={setShowCreatePost}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-md mx-auto max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Trade Post</DialogTitle>
            <DialogDescription className="text-slate-400">
              List an item you'd like to sell or trade
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Item Name</label>
              <Input
                placeholder="What are you selling?"
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white"
                disabled={submittingPost}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <Select value={category} onValueChange={setCategory} disabled={submittingPost}>
                <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-white">
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Price</label>
                <Input
                  placeholder="$0.00"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="bg-slate-700/50 border-slate-600 text-white"
                  disabled={submittingPost}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Condition</label>
                <Select value={condition} onValueChange={setCondition} disabled={submittingPost}>
                  <SelectTrigger className="bg-slate-700/50 border-slate-600 text-white">
                    <SelectValue placeholder="Condition" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 text-white">
                    {conditions.map((cond) => (
                      <SelectItem key={cond} value={cond}>{cond}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Description</label>
              <Textarea
                placeholder="Describe your item..."
                value={itemDescription}
                onChange={(e) => setItemDescription(e.target.value)}
                className="bg-slate-700/50 border-slate-600 text-white resize-none min-h-[100px]"
                disabled={submittingPost}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Images (Max 5)</label>
              <div className="space-y-3">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageSelect}
                  accept="image/*"
                  multiple
                  className="hidden"
                  disabled={submittingPost}
                />
                <Button
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={selectedImages.length >= 5 || submittingPost}
                  className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Add Images ({selectedImages.length}/5)
                </Button>
                
                {imagePreviews.length > 0 && (
                  <div className="grid grid-cols-3 gap-2">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="relative">
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="w-full h-20 object-cover rounded border border-slate-600"
                        />
                        <Button
                          size="sm"
                          variant="destructive"
                          className="absolute top-1 right-1 w-6 h-6 p-0 rounded-full"
                          onClick={() => removeImage(index)}
                          disabled={submittingPost}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowCreatePost(false)}
                disabled={submittingPost}
                className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreatePost}
                disabled={!itemName.trim() || !itemDescription.trim() || !category || !price.trim() || !condition || submittingPost}
                className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
              >
                {submittingPost ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  'Create Post'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent className="bg-slate-800 border-slate-700 text-white max-w-sm mx-auto">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Trade Post</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-400">
              Are you sure you want to delete this trade post? This action cannot be undone and will also delete all associated chat messages.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              className="bg-slate-700 text-white border-slate-600 hover:bg-slate-600"
              disabled={deletingPostId !== null}
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => postToDelete && handleDeletePost(postToDelete)}
              disabled={deletingPostId !== null}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deletingPostId ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}