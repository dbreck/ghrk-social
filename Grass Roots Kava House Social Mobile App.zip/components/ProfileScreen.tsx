import { useState, useEffect } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Alert, AlertDescription } from "./ui/alert";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { User, LogOut, Edit3, Save, X } from 'lucide-react';
import { supabase, User as UserType } from "../utils/supabase/client";
import { projectId, publicAnonKey } from "../utils/supabase/info";

interface ProfileScreenProps {
  accessToken: string;
  onSignOut: () => void;
}

export function ProfileScreen({ accessToken, onSignOut }: ProfileScreenProps) {
  const [user, setUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [updateLoading, setUpdateLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadProfile();
  }, [accessToken]);

  const loadProfile = async () => {
    try {
      console.log('Loading profile with token:', accessToken ? 'present' : 'missing');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/profile`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      console.log('Profile response status:', response.status);
      const data = await response.json();

      if (!response.ok) {
        console.error('Profile load failed:', data);
        
        // Handle JWT errors specifically
        if (response.status === 401 && (data.message?.includes('JWT') || data.message?.includes('Unauthorized'))) {
          console.log('JWT error detected, signing out');
          await supabase.auth.signOut();
          onSignOut();
          return;
        }
        
        setError(data.error || data.message || 'Failed to load profile');
        return;
      }

      console.log('Profile loaded successfully:', data.user);
      setUser(data.user);
      setEditName(data.user.name);
    } catch (err) {
      console.error('Profile load error:', err);
      setError('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateProfile = async () => {
    if (!editName.trim()) {
      setError('Name is required');
      return;
    }

    setUpdateLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          name: editName.trim(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to update profile');
        return;
      }

      setUser(data.user);
      setEditing(false);
      setSuccess('Profile updated successfully');
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('Failed to update profile');
      console.error('Profile update error:', err);
    } finally {
      setUpdateLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      onSignOut();
    } catch (err) {
      console.error('Sign out error:', err);
      onSignOut(); // Sign out anyway
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="h-full bg-slate-900 flex items-center justify-center p-6">
        <div className="text-center">
          <User className="w-12 h-12 text-slate-400 mx-auto mb-4 animate-pulse" />
          <p className="text-slate-400">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-slate-900 overflow-y-auto">
      <div className="p-6 pb-safe">
        <div className="max-w-sm mx-auto">
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-blue-600 to-blue-500 rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl text-white mb-2">Profile</h1>
            <p className="text-slate-400">Manage your account settings</p>
          </div>

          {error && (
            <Alert className="mb-6 bg-red-900/20 border-red-800 text-red-200">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-6 bg-green-900/20 border-green-800 text-green-200">
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          <Card className="mb-6 bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">Personal Information</CardTitle>
                {!editing && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setEditing(true)}
                    className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white"
                  >
                    <Edit3 className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-slate-300">Name</Label>
                {editing ? (
                  <div className="flex gap-2">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      disabled={updateLoading}
                      className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-blue-500"
                    />
                    <Button
                      size="sm"
                      onClick={handleUpdateProfile}
                      disabled={updateLoading}
                      className="bg-green-600 hover:bg-green-700 text-white px-3"
                    >
                      <Save className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditing(false);
                        setEditName(user?.name || '');
                        setError('');
                      }}
                      disabled={updateLoading}
                      className="bg-transparent border-slate-600 text-slate-300 hover:bg-slate-700 px-3"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <p className="text-white bg-slate-700 p-3 rounded-md">{user?.name}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Email</Label>
                <p className="text-white bg-slate-700 p-3 rounded-md">{user?.email}</p>
              </div>

              <div className="space-y-2">
                <Label className="text-slate-300">Member Since</Label>
                <p className="text-white bg-slate-700 p-3 rounded-md">{formatDate(user?.created_at)}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="pb-3">
              <CardTitle className="text-white">Account Actions</CardTitle>
              <CardDescription className="text-slate-400">
                Manage your account settings and sign out
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={handleSignOut}
                variant="destructive"
                className="w-full bg-red-600 hover:bg-red-700 text-white"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}