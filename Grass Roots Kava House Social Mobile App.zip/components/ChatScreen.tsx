import { useState, useEffect, useRef } from 'react';
import { Send, Search, MoreHorizontal, Hash, User, ArrowLeft, Loader2, MessageCircle } from 'lucide-react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { projectId, publicAnonKey } from "../utils/supabase/info";

interface Channel {
  id: string;
  name: string;
  description: string;
  type: string;
  created_at: string;
  created_by: string;
  last_message?: {
    content: string;
    user_name: string;
    created_at: string;
  };
  participant_count?: number;
  unread_count?: number;
}

interface Message {
  id: string;
  channel_id: string;
  user_id: string;
  user_name: string;
  content: string;
  created_at: string;
}

interface ChatScreenProps {
  accessToken: string;
}

export function ChatScreen({ accessToken }: ChatScreenProps) {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sendingMessage, setSendingMessage] = useState(false);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadChannels();
  }, [accessToken]);

  useEffect(() => {
    if (selectedChannel) {
      loadMessages(selectedChannel.id);
      // Set up polling for new messages
      const interval = setInterval(() => {
        loadMessages(selectedChannel.id);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [selectedChannel, accessToken]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadChannels = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/chat/recent`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to load channels');
        return;
      }

      setChannels(data.channels);
    } catch (err) {
      setError('Failed to load channels');
      console.error('Load channels error:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadMessages = async (channelId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/chat/channels/${channelId}/messages?limit=50`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to load messages');
        return;
      }

      setMessages(data.messages);
    } catch (err) {
      setError('Failed to load messages');
      console.error('Load messages error:', err);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedChannel || sendingMessage) return;

    setSendingMessage(true);
    setError("");

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-1f09dbfa/chat/channels/${selectedChannel.id}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          content: newMessage.trim(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Failed to send message');
        return;
      }

      setNewMessage("");
      // Reload messages to show the new one
      await loadMessages(selectedChannel.id);
      // Also reload channels to update last message
      await loadChannels();
    } catch (err) {
      setError('Failed to send message');
      console.error('Send message error:', err);
    } finally {
      setSendingMessage(false);
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatMessageTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getCurrentUserId = () => {
    // For now, we'll extract from the access token or use a placeholder
    // In a real app, you'd decode the JWT or get this from your auth context
    return "current-user"; // This would be the actual user ID
  };

  const filteredChannels = channels.filter(channel =>
    channel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    channel.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="h-full bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-slate-400 mx-auto mb-4 animate-spin" />
          <p className="text-slate-400">Loading chat...</p>
        </div>
      </div>
    );
  }

  if (selectedChannel) {
    return (
      <div className="flex flex-col h-full bg-slate-900">
        {/* Chat Header with gradient */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-700 border-b border-slate-600 p-4 flex items-center gap-3 relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500 opacity-5 rounded-full translate-x-12 -translate-y-12"></div>
          
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setSelectedChannel(null)}
            className="text-slate-300 hover:text-white hover:bg-slate-700/50 p-2 rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3 flex-1">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <Hash className="w-5 h-5 text-white" />
            </div>
            <div className="flex-1">
              <h2 className="font-medium text-white">{selectedChannel.name}</h2>
              <p className="text-sm text-slate-300">
                {selectedChannel.participant_count || 0} members
              </p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="text-slate-300 hover:text-white hover:bg-slate-700/50 p-2 rounded-full">
            <MoreHorizontal className="w-5 h-5" />
          </Button>
        </div>

        {error && (
          <Alert className="m-4 bg-red-900/20 border-red-800 text-red-200">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-slate-900 to-slate-800">
          {messages.length === 0 ? (
            <div className="text-center text-slate-400 mt-8">
              <Hash className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No messages yet. Be the first to start the conversation!</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.user_id === getCurrentUserId();
              return (
                <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] ${isMe ? 'order-2' : 'order-1'}`}>
                    {!isMe && (
                      <div className="flex items-center gap-2 mb-2">
                        <Avatar className="w-6 h-6 ring-1 ring-slate-600">
                          <AvatarFallback className="bg-gradient-to-r from-slate-600 to-slate-700 text-white text-xs">
                            {msg.user_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-slate-200">{msg.user_name}</span>
                        <span className="text-xs text-slate-500">{formatMessageTime(msg.created_at)}</span>
                      </div>
                    )}
                    <div 
                      className={`rounded-2xl px-4 py-3 ${
                        isMe 
                          ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/20' 
                          : 'bg-slate-700/50 backdrop-blur-sm text-slate-100 border border-slate-600/30'
                      }`}
                    >
                      <p className="leading-relaxed">{msg.content}</p>
                      {isMe && (
                        <div className="text-xs text-blue-100 mt-1 text-right opacity-80">
                          {formatMessageTime(msg.created_at)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="border-t border-slate-700 p-4 bg-slate-800/50 backdrop-blur-sm">
          <form onSubmit={sendMessage} className="flex items-center gap-3">
            <div className="flex-1 relative">
              <Input 
                placeholder="Type a message..."
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                disabled={sendingMessage}
                className="bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 rounded-full pr-12 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <Button 
              type="submit"
              disabled={sendingMessage || !newMessage.trim()}
              className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 rounded-full w-10 h-10 p-0 shadow-lg shadow-blue-500/20 disabled:opacity-50"
            >
              {sendingMessage ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-900">
      {/* Search with gradient background */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-700 p-4 border-b border-slate-600 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-20 h-20 bg-purple-500 opacity-5 rounded-full -translate-x-10 -translate-y-10"></div>
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input 
              placeholder="Search conversations..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-700/50 border-slate-600 text-white placeholder:text-slate-400 rounded-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {error && (
        <Alert className="m-4 bg-red-900/20 border-red-800 text-red-200">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Chat List */}
      <div className="flex-1 overflow-y-auto bg-gradient-to-b from-slate-900 to-slate-800">
        <div className="space-y-0">
          {filteredChannels.length === 0 ? (
            <div className="text-center text-slate-400 mt-8 p-4">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No conversations found</p>
            </div>
          ) : (
            filteredChannels.map((channel) => (
              <Card 
                key={channel.id} 
                className="rounded-none border-0 border-b border-slate-700/30 cursor-pointer hover:bg-slate-700/30 bg-slate-800/20 backdrop-blur-sm transition-all duration-200"
                onClick={() => setSelectedChannel(channel)}
              >
                <CardContent className="p-4 relative">
                  {/* Decorative element for active chats */}
                  {channel.unread_count && channel.unread_count > 0 && (
                    <div className="absolute left-0 top-1/2 w-1 h-8 bg-gradient-to-b from-blue-500 to-purple-500 rounded-r-full transform -translate-y-1/2"></div>
                  )}
                  
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Avatar className="w-12 h-12 ring-2 ring-slate-600/50">
                        <AvatarFallback className="text-white bg-gradient-to-r from-blue-600 to-purple-600">
                          <Hash className="w-5 h-5" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-slate-800"></div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium text-white truncate">{channel.name}</h3>
                        <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 text-xs">
                          {channel.participant_count || 0}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400 truncate">
                        {channel.last_message 
                          ? `${channel.last_message.user_name}: ${channel.last_message.content}`
                          : channel.description
                        }
                      </p>
                    </div>
                    
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-xs text-slate-500">
                        {channel.last_message 
                          ? formatTime(channel.last_message.created_at)
                          : formatTime(channel.created_at)
                        }
                      </span>
                      {channel.unread_count && channel.unread_count > 0 && (
                        <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs min-w-[20px] h-5 rounded-full flex items-center justify-center shadow-lg shadow-orange-500/20">
                          {channel.unread_count}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}