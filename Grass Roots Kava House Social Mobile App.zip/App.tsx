import { useState, useEffect } from 'react';
import { Home, MapPin, Calendar, ShoppingBag, User } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { HomeScreen } from "./components/HomeScreen";
import { FindScreen } from "./components/FindScreen";
import { EventsScreen } from "./components/EventsScreen";
import { TradeScreen } from "./components/TradeScreen";
import { SignInScreen } from "./components/SignInScreen";
import { SignUpScreen } from "./components/SignUpScreen";
import { ProfileScreen } from "./components/ProfileScreen";
import { supabase } from "./utils/supabase/client";
import grassRootsLogo from 'figma:asset/503581e363d6c44191311ef9890b30efb8c52110.png';

type AuthState = 'signin' | 'signup' | 'authenticated';

export default function App() {
  const [activeTab, setActiveTab] = useState("home");
  const [authState, setAuthState] = useState<AuthState>('signin');
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    checkSession();
    
    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Auth state changed:', event, session?.access_token ? 'token present' : 'no token');
      
      if (event === 'SIGNED_OUT' || !session?.access_token) {
        setAccessToken(null);
        setAuthState('signin');
        setActiveTab('home');
      } else if (session?.access_token) {
        // Validate the token before setting it
        const isValid = await validateToken(session.access_token);
        if (isValid) {
          setAccessToken(session.access_token);
          setAuthState('authenticated');
        } else {
          console.log('Invalid token, signing out');
          await supabase.auth.signOut();
          setAccessToken(null);
          setAuthState('signin');
        }
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const validateToken = async (token: string): Promise<boolean> => {
    try {
      // Check if token is properly formatted
      if (!token || typeof token !== 'string') {
        console.log('Token is not a string or is empty');
        return false;
      }

      const parts = token.split('.');
      if (parts.length !== 3) {
        console.log('Token does not have 3 parts');
        return false;
      }

      // Check if token is expired
      const payload = JSON.parse(atob(parts[1]));
      const now = Math.floor(Date.now() / 1000);
      
      if (payload.exp && payload.exp < now) {
        console.log('Token is expired');
        return false;
      }

      // Test the token by making a simple API call
      const { data, error } = await supabase.auth.getUser(token);
      
      if (error) {
        console.log('Token validation failed:', error.message);
        return false;
      }

      if (!data.user) {
        console.log('No user data returned');
        return false;
      }

      console.log('Token validation successful');
      return true;
    } catch (error) {
      console.log('Token validation error:', error);
      return false;
    }
  };

  const checkSession = async () => {
    try {
      console.log('Checking session...');
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error('Session check error:', error);
        setAuthState('signin');
        setLoading(false);
        return;
      }

      if (session?.access_token) {
        console.log('Session found, validating token...');
        // Validate the token before using it
        const isValid = await validateToken(session.access_token);
        
        if (isValid) {
          setAccessToken(session.access_token);
          setAuthState('authenticated');
          console.log('Session is valid');
        } else {
          console.log('Session token is invalid, clearing session');
          await supabase.auth.signOut();
          setAccessToken(null);
          setAuthState('signin');
        }
      } else {
        console.log('No session found');
        setAuthState('signin');
      }
    } catch (error) {
      console.error('Session check error:', error);
      setAuthState('signin');
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async (token: string) => {
    console.log('Handling sign in with token');
    
    // Validate the token before setting it
    const isValid = await validateToken(token);
    
    if (isValid) {
      setAccessToken(token);
      setAuthState('authenticated');
      setActiveTab('home');
      console.log('Sign in successful');
    } else {
      console.log('Invalid token provided during sign in');
      setAccessToken(null);
      setAuthState('signin');
    }
  };

  const handleSignUp = () => {
    setAuthState('signin');
  };

  const handleSignOut = async () => {
    console.log('Signing out...');
    try {
      await supabase.auth.signOut();
    } catch (error) {
      console.error('Sign out error:', error);
    }
    
    setAccessToken(null);
    setAuthState('signin');
    setActiveTab('home');
  };

  const switchToSignUp = () => {
    setAuthState('signup');
  };

  const switchToSignIn = () => {
    setAuthState('signin');
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4">
            <img 
              src={grassRootsLogo} 
              alt="Grass Roots Kava House" 
              className="w-full h-auto object-contain filter brightness-0 invert animate-pulse"
            />
          </div>
          <p className="text-slate-400">Loading...</p>
        </div>
      </div>
    );
  }

  // Authentication screens
  if (authState === 'signin') {
    return <SignInScreen onSignIn={handleSignIn} onSwitchToSignUp={switchToSignUp} />;
  }

  if (authState === 'signup') {
    return <SignUpScreen onSignUp={handleSignUp} onSwitchToSignIn={switchToSignIn} />;
  }

  // Main app (authenticated state) - only render if we have a valid token
  if (!accessToken) {
    return <SignInScreen onSignIn={handleSignIn} onSwitchToSignUp={switchToSignUp} />;
  }

  return (
    <div className="min-h-screen bg-slate-900 dark flex flex-col max-w-md mx-auto">
      {/* Header with gradient background */}
      <div className="bg-gradient-to-r from-slate-800 via-slate-700 to-slate-800 text-white p-4 relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white rounded-full -translate-x-16 -translate-y-16"></div>
          <div className="absolute top-0 right-0 w-24 h-24 bg-white rounded-full translate-x-12 -translate-y-12"></div>
          <div className="absolute bottom-0 left-1/2 w-40 h-40 bg-white rounded-full translate-y-20 -translate-x-20"></div>
        </div>
        
        <div className="relative flex items-center justify-center">
          <div className="w-[85%] flex items-center justify-center">
            <img 
              src={grassRootsLogo} 
              alt="Grass Roots Kava House" 
              className="w-full h-auto object-contain filter brightness-0 invert"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <div className="flex-1 overflow-hidden">
          <TabsContent value="home" className="h-full m-0">
            <HomeScreen accessToken={accessToken} />
          </TabsContent>
          <TabsContent value="find" className="h-full m-0">
            <FindScreen accessToken={accessToken} />
          </TabsContent>
          <TabsContent value="events" className="h-full m-0">
            <EventsScreen accessToken={accessToken} />
          </TabsContent>
          <TabsContent value="trade" className="h-full m-0">
            <TradeScreen accessToken={accessToken} />
          </TabsContent>
          <TabsContent value="profile" className="h-full m-0">
            <ProfileScreen accessToken={accessToken} onSignOut={handleSignOut} />
          </TabsContent>
        </div>

        {/* Bottom Navigation with gradient */}
        <TabsList className="grid w-full grid-cols-5 rounded-none bg-slate-800 border-t border-slate-700 h-16 p-0 relative overflow-hidden">
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-800 via-slate-750 to-slate-800"></div>
          
          <TabsTrigger 
            value="home" 
            className="relative z-10 flex flex-col gap-1 data-[state=active]:bg-gradient-to-t data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white text-slate-300 hover:text-white rounded-none transition-all duration-200"
          >
            <Home className="w-5 h-5" />
            <span className="text-xs">Home</span>
          </TabsTrigger>
          <TabsTrigger 
            value="find" 
            className="relative z-10 flex flex-col gap-1 data-[state=active]:bg-gradient-to-t data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white text-slate-300 hover:text-white rounded-none transition-all duration-200"
          >
            <MapPin className="w-5 h-5" />
            <span className="text-xs">Find</span>
          </TabsTrigger>
          <TabsTrigger 
            value="events" 
            className="relative z-10 flex flex-col gap-1 data-[state=active]:bg-gradient-to-t data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white text-slate-300 hover:text-white rounded-none transition-all duration-200"
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs">Events</span>
          </TabsTrigger>
          <TabsTrigger 
            value="trade" 
            className="relative z-10 flex flex-col gap-1 data-[state=active]:bg-gradient-to-t data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white text-slate-300 hover:text-white rounded-none transition-all duration-200"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="text-xs">Trade</span>
          </TabsTrigger>
          <TabsTrigger 
            value="profile" 
            className="relative z-10 flex flex-col gap-1 data-[state=active]:bg-gradient-to-t data-[state=active]:from-blue-600 data-[state=active]:to-blue-500 data-[state=active]:text-white text-slate-300 hover:text-white rounded-none transition-all duration-200"
          >
            <User className="w-5 h-5" />
            <span className="text-xs">Profile</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
    </div>
  );
}