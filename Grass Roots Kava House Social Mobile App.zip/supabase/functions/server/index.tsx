import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Create Supabase client for admin operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-1f09dbfa/health", (c) => {
  return c.json({ status: "ok" });
});

// Sign up endpoint
app.post("/make-server-1f09dbfa/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log(`Sign up error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      message: "User created successfully",
      user: {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.user_metadata?.name
      }
    });
  } catch (error) {
    console.log(`Sign up server error: ${error}`);
    return c.json({ error: "Internal server error during sign up" }, 500);
  }
});

// Get user profile endpoint (requires authentication)
app.get("/make-server-1f09dbfa/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Profile auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    return c.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name,
        created_at: user.created_at
      }
    });
  } catch (error) {
    console.log(`Profile server error: ${error}`);
    return c.json({ error: "Internal server error while fetching profile" }, 500);
  }
});

// Update user profile endpoint (requires authentication)
app.put("/make-server-1f09dbfa/profile", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      console.log(`Profile update auth error: ${authError?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { name } = await c.req.json();
    
    if (!name) {
      return c.json({ error: "Name is required" }, 400);
    }

    const { data, error } = await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: { name }
    });

    if (error) {
      console.log(`Profile update error: ${error.message}`);
      return c.json({ error: error.message }, 400);
    }

    return c.json({
      message: "Profile updated successfully",
      user: {
        id: data.user?.id,
        email: data.user?.email,
        name: data.user?.user_metadata?.name
      }
    });
  } catch (error) {
    console.log(`Profile update server error: ${error}`);
    return c.json({ error: "Internal server error while updating profile" }, 500);
  }
});

// Get chat channels endpoint (requires authentication)
app.get("/make-server-1f09dbfa/chat/channels", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Chat channels auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get all channels from KV store
    const channels = await kv.getByPrefix("chat:channel:");
    
    // Create default channels if none exist
    if (channels.length === 0) {
      const defaultChannels = [
        {
          id: "general",
          name: "General Chat",
          description: "Community discussions and general kava talk",
          type: "channel",
          created_at: new Date().toISOString(),
          created_by: "system"
        },
        {
          id: "newbies",
          name: "Kava Newbies",
          description: "Questions and guidance for newcomers",
          type: "channel",
          created_at: new Date().toISOString(),
          created_by: "system"
        },
        {
          id: "events",
          name: "Events & Ceremonies",
          description: "Upcoming events and ceremony planning",
          type: "channel",
          created_at: new Date().toISOString(),
          created_by: "system"
        }
      ];

      for (const channel of defaultChannels) {
        await kv.set(`chat:channel:${channel.id}`, channel);
      }

      return c.json({ channels: defaultChannels });
    }

    return c.json({ channels });
  } catch (error) {
    console.log(`Chat channels server error: ${error}`);
    return c.json({ error: "Internal server error while fetching channels" }, 500);
  }
});

// Get messages for a channel endpoint (requires authentication)
app.get("/make-server-1f09dbfa/chat/channels/:channelId/messages", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Chat messages auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const channelId = c.req.param('channelId');
    const limit = Number(c.req.query('limit')) || 50;

    // Get messages for the channel
    const messageKeys = await kv.getByPrefix(`chat:message:${channelId}:`);
    
    // Sort by timestamp (newest first) and limit
    const messages = messageKeys
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit)
      .reverse(); // Reverse to show oldest first

    return c.json({ messages });
  } catch (error) {
    console.log(`Chat messages server error: ${error}`);
    return c.json({ error: "Internal server error while fetching messages" }, 500);
  }
});

// Send message to channel endpoint (requires authentication)
app.post("/make-server-1f09dbfa/chat/channels/:channelId/messages", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Send message auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const channelId = c.req.param('channelId');
    const { content } = await c.req.json();

    if (!content || content.trim().length === 0) {
      return c.json({ error: "Message content is required" }, 400);
    }

    if (content.length > 1000) {
      return c.json({ error: "Message too long (max 1000 characters)" }, 400);
    }

    // Create message
    const messageId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const message = {
      id: messageId,
      channel_id: channelId,
      user_id: user.id,
      user_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Anonymous',
      content: content.trim(),
      created_at: new Date().toISOString()
    };

    // Store message in KV store
    await kv.set(`chat:message:${channelId}:${messageId}`, message);

    // Update channel's last message info
    const channelKey = `chat:channel:${channelId}`;
    const channel = await kv.get(channelKey);
    if (channel) {
      channel.last_message = {
        content: content.trim(),
        user_name: message.user_name,
        created_at: message.created_at
      };
      await kv.set(channelKey, channel);
    }

    return c.json({ 
      message: "Message sent successfully",
      data: message 
    });
  } catch (error) {
    console.log(`Send message server error: ${error}`);
    return c.json({ error: "Internal server error while sending message" }, 500);
  }
});

// Get recent messages across all channels for chat list preview (requires authentication)
app.get("/make-server-1f09dbfa/chat/recent", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Chat recent auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get all channels
    const channels = await kv.getByPrefix("chat:channel:");
    
    // For each channel, get the most recent message
    const channelsWithLastMessage = [];
    
    for (const channel of channels) {
      const recentMessages = await kv.getByPrefix(`chat:message:${channel.id}:`);
      const lastMessage = recentMessages
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
      
      // Count messages for participants simulation
      const messageCount = recentMessages.length;
      const participantCount = Math.max(1, Math.floor(messageCount / 3) + Math.floor(Math.random() * 10));
      
      channelsWithLastMessage.push({
        ...channel,
        last_message: lastMessage,
        participant_count: participantCount,
        unread_count: 0 // We'll implement this later if needed
      });
    }

    // Sort by last message time
    channelsWithLastMessage.sort((a, b) => {
      const aTime = a.last_message?.created_at || a.created_at;
      const bTime = b.last_message?.created_at || b.created_at;
      return new Date(bTime).getTime() - new Date(aTime).getTime();
    });

    return c.json({ channels: channelsWithLastMessage });
  } catch (error) {
    console.log(`Chat recent server error: ${error}`);
    return c.json({ error: "Internal server error while fetching recent chats" }, 500);
  }
});

// Get social feed posts endpoint (requires authentication)
app.get("/make-server-1f09dbfa/social/feed", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Social feed auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const limit = Number(c.req.query('limit')) || 20;
    
    // Get all posts from KV store
    const posts = await kv.getByPrefix("social:post:");
    
    // Sort by timestamp (newest first) and limit
    const sortedPosts = posts
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);

    return c.json({ posts: sortedPosts });
  } catch (error) {
    console.log(`Social feed server error: ${error}`);
    return c.json({ error: "Internal server error while fetching social feed" }, 500);
  }
});

// Create social post endpoint (requires authentication)
app.post("/make-server-1f09dbfa/social/posts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Create post auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { content, media_url, media_type } = await c.req.json();

    if (!content || content.trim().length === 0) {
      return c.json({ error: "Post content is required" }, 400);
    }

    if (content.length > 2000) {
      return c.json({ error: "Post too long (max 2000 characters)" }, 400);
    }

    // Create post
    const postId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const post = {
      id: postId,
      user_id: user.id,
      user_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Anonymous',
      user_email: user.email,
      content: content.trim(),
      media_url: media_url || null,
      media_type: media_type || null,
      likes: 0,
      comments: 0,
      shares: 0,
      liked_by: [],
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Store post in KV store
    await kv.set(`social:post:${postId}`, post);

    return c.json({ 
      message: "Post created successfully",
      post: post 
    });
  } catch (error) {
    console.log(`Create post server error: ${error}`);
    return c.json({ error: "Internal server error while creating post" }, 500);
  }
});

// Like/unlike a social post endpoint (requires authentication)
app.post("/make-server-1f09dbfa/social/posts/:postId/like", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Like post auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const postId = c.req.param('postId');
    const postKey = `social:post:${postId}`;
    
    // Get the post
    const post = await kv.get(postKey);
    if (!post) {
      return c.json({ error: "Post not found" }, 404);
    }

    // Check if user already liked the post
    const likedBy = post.liked_by || [];
    const userIndex = likedBy.indexOf(user.id);
    const isLiked = userIndex !== -1;

    if (isLiked) {
      // Unlike - remove user from liked_by array
      post.liked_by = likedBy.filter(id => id !== user.id);
      post.likes = Math.max(0, post.likes - 1);
    } else {
      // Like - add user to liked_by array
      post.liked_by = [...likedBy, user.id];
      post.likes = post.likes + 1;
    }

    post.updated_at = new Date().toISOString();

    // Update post in KV store
    await kv.set(postKey, post);

    return c.json({ 
      message: isLiked ? "Post unliked" : "Post liked",
      post: post,
      liked: !isLiked
    });
  } catch (error) {
    console.log(`Like post server error: ${error}`);
    return c.json({ error: "Internal server error while liking post" }, 500);
  }
});

// Delete a social post endpoint (requires authentication and ownership)
app.delete("/make-server-1f09dbfa/social/posts/:postId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Delete post auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const postId = c.req.param('postId');
    const postKey = `social:post:${postId}`;
    
    // Get the post
    const post = await kv.get(postKey);
    if (!post) {
      return c.json({ error: "Post not found" }, 404);
    }

    // Check if user is the owner of the post
    if (post.user_id !== user.id) {
      return c.json({ error: "You can only delete your own posts" }, 403);
    }

    // Delete post from KV store
    await kv.del(postKey);

    return c.json({ 
      message: "Post deleted successfully",
      deleted_post_id: postId
    });
  } catch (error) {
    console.log(`Delete post server error: ${error}`);
    return c.json({ error: "Internal server error while deleting post" }, 500);
  }
});

// Get events endpoint (requires authentication)
app.get("/make-server-1f09dbfa/events", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Events auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const limit = Number(c.req.query('limit')) || 50;
    
    // Get all events from KV store
    const events = await kv.getByPrefix("event:");
    
    // Sort by event date (upcoming first)
    const sortedEvents = events
      .sort((a, b) => new Date(a.event_date).getTime() - new Date(b.event_date).getTime())
      .slice(0, limit);

    return c.json({ events: sortedEvents });
  } catch (error) {
    console.log(`Events server error: ${error}`);
    return c.json({ error: "Internal server error while fetching events" }, 500);
  }
});

// Create event endpoint (requires authentication)
app.post("/make-server-1f09dbfa/events", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Create event auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { title, description, event_date, event_time, location, max_attendees, category, cover_image } = await c.req.json();

    if (!title || !description || !event_date || !event_time || !location) {
      return c.json({ error: "Title, description, date, time, and location are required" }, 400);
    }

    if (title.length > 100) {
      return c.json({ error: "Title too long (max 100 characters)" }, 400);
    }

    if (description.length > 1000) {
      return c.json({ error: "Description too long (max 1000 characters)" }, 400);
    }

    // Validate event date is in the future
    const eventDateTime = new Date(`${event_date}T${event_time}`);
    if (eventDateTime <= new Date()) {
      return c.json({ error: "Event date must be in the future" }, 400);
    }

    // Create event
    const eventId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const event = {
      id: eventId,
      title: title.trim(),
      description: description.trim(),
      event_date,
      event_time,
      location: location.trim(),
      max_attendees: max_attendees || 50,
      category: category || 'social',
      cover_image: cover_image || null,
      host_id: user.id,
      host_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Anonymous',
      attendees: [],
      interested: [],
      attending_count: 0,
      interested_count: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Store event in KV store
    await kv.set(`event:${eventId}`, event);

    return c.json({ 
      message: "Event created successfully",
      event: event 
    });
  } catch (error) {
    console.log(`Create event server error: ${error}`);
    return c.json({ error: "Internal server error while creating event" }, 500);
  }
});

// RSVP to event endpoint (requires authentication)
app.post("/make-server-1f09dbfa/events/:eventId/rsvp", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`RSVP auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const eventId = c.req.param('eventId');
    const { status } = await c.req.json(); // 'going', 'interested', or 'not_going'
    
    if (!['going', 'interested', 'not_going'].includes(status)) {
      return c.json({ error: "Invalid RSVP status" }, 400);
    }

    const eventKey = `event:${eventId}`;
    
    // Get the event
    const event = await kv.get(eventKey);
    if (!event) {
      return c.json({ error: "Event not found" }, 404);
    }

    // Check if event is in the past
    const eventDateTime = new Date(`${event.event_date}T${event.event_time}`);
    if (eventDateTime <= new Date()) {
      return c.json({ error: "Cannot RSVP to past events" }, 400);
    }

    // Initialize arrays if they don't exist
    event.attendees = event.attendees || [];
    event.interested = event.interested || [];

    // Remove user from both arrays first
    event.attendees = event.attendees.filter(id => id !== user.id);
    event.interested = event.interested.filter(id => id !== user.id);

    // Add user to appropriate array based on status
    if (status === 'going') {
      // Check max attendees limit
      if (event.attendees.length >= event.max_attendees) {
        return c.json({ error: "Event is at maximum capacity" }, 400);
      }
      event.attendees.push(user.id);
    } else if (status === 'interested') {
      event.interested.push(user.id);
    }
    // For 'not_going', user is removed from both arrays (already done above)

    // Update counts
    event.attending_count = event.attendees.length;
    event.interested_count = event.interested.length;
    event.updated_at = new Date().toISOString();

    // Update event in KV store
    await kv.set(eventKey, event);

    return c.json({ 
      message: `RSVP updated to ${status}`,
      event: event,
      user_status: status
    });
  } catch (error) {
    console.log(`RSVP server error: ${error}`);
    return c.json({ error: "Internal server error while updating RSVP" }, 500);
  }
});

// Get user's events (attending) endpoint (requires authentication)
app.get("/make-server-1f09dbfa/events/my-events", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`My events auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    // Get all events from KV store
    const allEvents = await kv.getByPrefix("event:");
    
    // Filter events where user is attending
    const myEvents = allEvents.filter(event => 
      event.attendees && event.attendees.includes(user.id)
    );

    // Sort by event date (upcoming first)
    const sortedEvents = myEvents
      .sort((a, b) => new Date(a.event_date).getTime() - new Date(b.event_date).getTime());

    return c.json({ events: sortedEvents });
  } catch (error) {
    console.log(`My events server error: ${error}`);
    return c.json({ error: "Internal server error while fetching user events" }, 500);
  }
});

// Get single event details endpoint (requires authentication)
app.get("/make-server-1f09dbfa/events/:eventId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Event details auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const eventId = c.req.param('eventId');
    const event = await kv.get(`event:${eventId}`);
    
    if (!event) {
      return c.json({ error: "Event not found" }, 404);
    }

    // Determine user's RSVP status
    let userStatus = 'not_going';
    if (event.attendees && event.attendees.includes(user.id)) {
      userStatus = 'going';
    } else if (event.interested && event.interested.includes(user.id)) {
      userStatus = 'interested';
    }

    return c.json({ 
      event: event,
      user_status: userStatus
    });
  } catch (error) {
    console.log(`Event details server error: ${error}`);
    return c.json({ error: "Internal server error while fetching event details" }, 500);
  }
});

// Get Mapbox access token endpoint (public)
app.get("/make-server-1f09dbfa/mapbox-token", async (c) => {
  try {
    const mapboxToken = Deno.env.get('MAPBOX_ACCESS_TOKEN');
    
    if (!mapboxToken) {
      console.log('Mapbox access token not found in environment');
      return c.json({ error: "Mapbox token not available" }, 500);
    }

    return c.json({ token: mapboxToken });
  } catch (error) {
    console.log(`Mapbox token server error: ${error}`);
    return c.json({ error: "Internal server error while fetching Mapbox token" }, 500);
  }
});

// Geolocation endpoint using Google Geolocation API (public)
app.post("/make-server-1f09dbfa/geolocation", async (c) => {
  try {
    const googleApiKey = Deno.env.get('GOOGLE_GEOLOCATION_API_KEY');
    
    if (!googleApiKey) {
      console.log('Google Geolocation API key not found in environment');
      return c.json({ error: "Geolocation service not available" }, 500);
    }

    const response = await fetch(`https://www.googleapis.com/geolocation/v1/geolocate?key=${googleApiKey}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        considerIp: true,
      }),
    });

    if (!response.ok) {
      console.log(`Google Geolocation API error: ${response.status} ${response.statusText}`);
      return c.json({ error: "Failed to get location" }, 500);
    }

    const data = await response.json();
    return c.json(data);
  } catch (error) {
    console.log(`Geolocation server error: ${error}`);
    return c.json({ error: "Internal server error while getting location" }, 500);
  }
});

// Update event endpoint (requires authentication and ownership)
app.put("/make-server-1f09dbfa/events/:eventId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Update event auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const eventId = c.req.param('eventId');
    const { title, description, event_date, event_time, location, max_attendees, category, cover_image } = await c.req.json();

    // Get the existing event
    const existingEvent = await kv.get(`event:${eventId}`);
    if (!existingEvent) {
      return c.json({ error: "Event not found" }, 404);
    }

    // Check if user is the host (owner) of the event
    if (existingEvent.host_id !== user.id) {
      return c.json({ error: "You can only edit your own events" }, 403);
    }

    if (!title || !description || !event_date || !event_time || !location) {
      return c.json({ error: "Title, description, date, time, and location are required" }, 400);
    }

    if (title.length > 100) {
      return c.json({ error: "Title too long (max 100 characters)" }, 400);
    }

    if (description.length > 1000) {
      return c.json({ error: "Description too long (max 1000 characters)" }, 400);
    }

    // Validate event date is in the future
    const eventDateTime = new Date(`${event_date}T${event_time}`);
    if (eventDateTime <= new Date()) {
      return c.json({ error: "Event date must be in the future" }, 400);
    }

    // Validate max_attendees doesn't go below current attendee count
    if (max_attendees < existingEvent.attending_count) {
      return c.json({ error: `Cannot reduce max attendees below current attendee count (${existingEvent.attending_count})` }, 400);
    }

    // Update the event while preserving attendee data
    const updatedEvent = {
      ...existingEvent,
      title: title.trim(),
      description: description.trim(),
      event_date,
      event_time,
      location: location.trim(),
      max_attendees: max_attendees || 50,
      category: category || 'social',
      cover_image: cover_image !== undefined ? cover_image : existingEvent.cover_image,
      updated_at: new Date().toISOString()
    };

    // Store updated event in KV store
    await kv.set(`event:${eventId}`, updatedEvent);

    return c.json({ 
      message: "Event updated successfully",
      event: updatedEvent 
    });
  } catch (error) {
    console.log(`Update event server error: ${error}`);
    return c.json({ error: "Internal server error while updating event" }, 500);
  }
});

// Delete event endpoint (requires authentication and ownership)
app.delete("/make-server-1f09dbfa/events/:eventId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Delete event auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const eventId = c.req.param('eventId');
    
    // Get the existing event
    const existingEvent = await kv.get(`event:${eventId}`);
    if (!existingEvent) {
      return c.json({ error: "Event not found" }, 404);
    }

    // Check if user is the host (owner) of the event
    if (existingEvent.host_id !== user.id) {
      return c.json({ error: "You can only delete your own events" }, 403);
    }

    // Delete event from KV store
    await kv.del(`event:${eventId}`);

    return c.json({ 
      message: "Event deleted successfully",
      deleted_event_id: eventId
    });
  } catch (error) {
    console.log(`Delete event server error: ${error}`);
    return c.json({ error: "Internal server error while deleting event" }, 500);
  }
});

// Get trade posts endpoint (requires authentication)
app.get("/make-server-1f09dbfa/trade/posts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Trade posts auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const limit = Number(c.req.query('limit')) || 20;
    const category = c.req.query('category');
    
    // Get all trade posts from KV store
    let tradePosts = await kv.getByPrefix("trade:post:");
    
    // Filter by category if provided
    if (category && category !== 'all') {
      tradePosts = tradePosts.filter(post => post.category === category);
    }
    
    // Sort by timestamp (newest first) and limit
    const sortedPosts = tradePosts
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);

    return c.json({ posts: sortedPosts });
  } catch (error) {
    console.log(`Trade posts server error: ${error}`);
    return c.json({ error: "Internal server error while fetching trade posts" }, 500);
  }
});

// Create trade post endpoint (requires authentication)
app.post("/make-server-1f09dbfa/trade/posts", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Create trade post auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const { item_name, item_description, category, price, condition, images } = await c.req.json();

    if (!item_name || !item_description || !category || !price || !condition) {
      return c.json({ error: "Item name, description, category, price, and condition are required" }, 400);
    }

    if (item_name.length > 100) {
      return c.json({ error: "Item name too long (max 100 characters)" }, 400);
    }

    if (item_description.length > 1000) {
      return c.json({ error: "Item description too long (max 1000 characters)" }, 400);
    }

    if (images && images.length > 5) {
      return c.json({ error: "Maximum 5 images allowed" }, 400);
    }

    // Validate condition
    const validConditions = ['New', 'Like New', 'Good', 'Well Worn'];
    if (!validConditions.includes(condition)) {
      return c.json({ error: "Invalid condition" }, 400);
    }

    // Create trade post
    const postId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const tradePost = {
      id: postId,
      user_id: user.id,
      user_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Anonymous',
      user_email: user.email,
      item_name: item_name.trim(),
      item_description: item_description.trim(),
      category: category.trim(),
      price: price.trim(),
      condition,
      images: images || [],
      chat_count: 0,
      views: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Store trade post in KV store
    await kv.set(`trade:post:${postId}`, tradePost);

    return c.json({ 
      message: "Trade post created successfully",
      post: tradePost 
    });
  } catch (error) {
    console.log(`Create trade post server error: ${error}`);
    return c.json({ error: "Internal server error while creating trade post" }, 500);
  }
});

// Delete trade post endpoint (requires authentication and ownership)
app.delete("/make-server-1f09dbfa/trade/posts/:postId", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Delete trade post auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const postId = c.req.param('postId');
    const postKey = `trade:post:${postId}`;
    
    // Get the trade post
    const tradePost = await kv.get(postKey);
    if (!tradePost) {
      return c.json({ error: "Trade post not found" }, 404);
    }

    // Check if user is the owner of the post
    if (tradePost.user_id !== user.id) {
      return c.json({ error: "You can only delete your own trade posts" }, 403);
    }

    // Delete trade post from KV store
    await kv.del(postKey);

    // Also delete associated chat messages
    const chatMessages = await kv.getByPrefix(`trade:chat:${postId}:`);
    for (const message of chatMessages) {
      await kv.del(`trade:chat:${postId}:${message.id}`);
    }

    return c.json({ 
      message: "Trade post deleted successfully",
      deleted_post_id: postId
    });
  } catch (error) {
    console.log(`Delete trade post server error: ${error}`);
    return c.json({ error: "Internal server error while deleting trade post" }, 500);
  }
});

// Get trade post chat messages endpoint (requires authentication)
app.get("/make-server-1f09dbfa/trade/posts/:postId/chat", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Trade chat auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const postId = c.req.param('postId');
    const limit = Number(c.req.query('limit')) || 50;

    // Verify trade post exists
    const tradePost = await kv.get(`trade:post:${postId}`);
    if (!tradePost) {
      return c.json({ error: "Trade post not found" }, 404);
    }

    // Get chat messages for the trade post
    const messageKeys = await kv.getByPrefix(`trade:chat:${postId}:`);
    
    // Sort by timestamp (newest first) and limit
    const messages = messageKeys
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit)
      .reverse(); // Reverse to show oldest first

    return c.json({ 
      messages,
      trade_post: tradePost
    });
  } catch (error) {
    console.log(`Trade chat server error: ${error}`);
    return c.json({ error: "Internal server error while fetching trade chat" }, 500);
  }
});

// Send message to trade post chat endpoint (requires authentication)
app.post("/make-server-1f09dbfa/trade/posts/:postId/chat", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: "Authorization token required" }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user) {
      console.log(`Send trade chat message auth error: ${error?.message}`);
      return c.json({ error: "Unauthorized" }, 401);
    }

    const postId = c.req.param('postId');
    const { content } = await c.req.json();

    if (!content || content.trim().length === 0) {
      return c.json({ error: "Message content is required" }, 400);
    }

    if (content.length > 500) {
      return c.json({ error: "Message too long (max 500 characters)" }, 400);
    }

    // Verify trade post exists
    const tradePost = await kv.get(`trade:post:${postId}`);
    if (!tradePost) {
      return c.json({ error: "Trade post not found" }, 404);
    }

    // Create message
    const messageId = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const message = {
      id: messageId,
      trade_post_id: postId,
      user_id: user.id,
      user_name: user.user_metadata?.name || user.email?.split('@')[0] || 'Anonymous',
      content: content.trim(),
      is_poster: user.id === tradePost.user_id,
      created_at: new Date().toISOString()
    };

    // Store message in KV store
    await kv.set(`trade:chat:${postId}:${messageId}`, message);

    // Update trade post's chat count
    tradePost.chat_count = (tradePost.chat_count || 0) + 1;
    tradePost.updated_at = new Date().toISOString();
    await kv.set(`trade:post:${postId}`, tradePost);

    return c.json({ 
      message: "Message sent successfully",
      data: message 
    });
  } catch (error) {
    console.log(`Send trade chat message server error: ${error}`);
    return c.json({ error: "Internal server error while sending trade chat message" }, 500);
  }
});

Deno.serve(app.fetch);